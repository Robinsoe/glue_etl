create view u_inj (api12, api10, injectiondate, gas_airinjected_mcf, steam_waterinjected_bbl) as
SELECT injection_ge2018.apinumber                                      AS api12,
       "left"(injection_ge2018.apinumber::text, 10)::character varying AS api10,
       injection_ge2018.injectiondate,
       sum(injection_ge2018.gasairinjected)                            AS gas_airinjected_mcf,
       sum(injection_ge2018.steamwaterinjected)                        AS steam_waterinjected_bbl
FROM calgem.injection_ge2018
GROUP BY injection_ge2018.apinumber, injection_ge2018.injectiondate
UNION
SELECT (w.api10 || '00'::text)::character varying AS api12,
       w.api10::character varying                 AS api10,
       i.injectiondate,
       sum(i.gas_airinjected_mcf)                 AS gas_airinjected_mcf,
       sum(i.steam_waterinjected_bbl)             AS steam_waterinjected_bbl
FROM calgem.injection_pre2018 i
         JOIN calgem.wells_pwt_map w ON i.pwt_id::numeric = w.pwt_id
GROUP BY w.api10, i.injectiondate;

alter table u_inj
    owner to crc;

