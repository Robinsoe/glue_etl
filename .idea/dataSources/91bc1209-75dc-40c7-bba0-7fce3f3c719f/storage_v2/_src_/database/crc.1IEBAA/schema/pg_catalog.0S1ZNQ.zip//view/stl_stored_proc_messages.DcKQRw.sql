create view stl_stored_proc_messages(userid, query, loglevel, message, linenum, recordtime) as
SELECT stll_stored_proc_messages.userid,
       stll_stored_proc_messages.query,
       stll_stored_proc_messages.loglevel,
       stll_stored_proc_messages.message,
       stll_stored_proc_messages.linenum,
       stll_stored_proc_messages.recordtime
FROM stll_stored_proc_messages;

alter table stl_stored_proc_messages
    owner to rdsdb;

