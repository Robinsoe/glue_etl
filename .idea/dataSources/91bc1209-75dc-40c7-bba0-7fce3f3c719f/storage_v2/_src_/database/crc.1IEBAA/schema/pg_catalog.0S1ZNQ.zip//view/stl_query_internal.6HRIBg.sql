create view stl_query_internal (userid, query, label, xid, pid, database, querytxt, starttime, endtime, aborted) as
SELECT stll_query_internal.userid,
       stll_query_internal.query,
       stll_query_internal."label",
       stll_query_internal.xid,
       stll_query_internal.pid,
       stll_query_internal."database",
       stll_query_internal.querytxt,
       stll_query_internal.starttime,
       stll_query_internal.endtime,
       stll_query_internal.aborted
FROM stll_query_internal;

alter table stl_query_internal
    owner to rdsdb;

