create view stl_file_scan(userid, query, slice, name, lines, bytes, loadtime, curtime) as
SELECT stll_file_scan.userid,
       stll_file_scan.query,
       stll_file_scan.slice,
       stll_file_scan.name,
       stll_file_scan."lines",
       stll_file_scan.bytes,
       stll_file_scan.loadtime,
       stll_file_scan.curtime
FROM stll_file_scan;

alter table stl_file_scan
    owner to rdsdb;

