create view stl_hllsketch_column_linker(userid, query, tbl, columnname, sqloperation) as
SELECT stll_hllsketch_column_linker.userid,
       stll_hllsketch_column_linker.query,
       stll_hllsketch_column_linker.tbl,
       stll_hllsketch_column_linker.columnname,
       stll_hllsketch_column_linker.sqloperation
FROM stll_hllsketch_column_linker;

alter table stl_hllsketch_column_linker
    owner to rdsdb;

