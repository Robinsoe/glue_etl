CREATE VIEW xspoc_high_res_views.dv_tblxdiagrodresults AS
SELECT "nodeid"
     , "date"
     , "topmaxstress"
     , "rodnum"
     , "dragfrictioncoefficient"
     , "grade"
     , "rodguideid"
     , "guidecountperrod"
     , "length"
     , "loading"
     , "bottomminstress"
     , "topminstress"
     , "diameter"
     , "partition_1"        "xspoc_source"
     , "max"("partition_2") "p_2"
FROM xspoc_high_res.tblxdiagrodresults
GROUP BY "topmaxstress", "rodnum", "dragfrictioncoefficient", "grade", "date", "rodguideid", "guidecountperrod",
         "length", "loading", "nodeid", "bottomminstress", "topminstress", "diameter", "partition_1"
ORDER BY "nodeid" ASC, "date" DESC
with no schema binding;

alter table dv_tblxdiagrodresults
    owner to crc;

