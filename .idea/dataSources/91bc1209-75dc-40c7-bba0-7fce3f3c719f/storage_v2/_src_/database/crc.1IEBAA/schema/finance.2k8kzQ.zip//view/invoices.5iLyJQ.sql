create or replace view finance.invoices(vendor_no, invoice_no, invoice_id, service_date, rep, bpa_number) as
SELECT DISTINCT suppliers.segment1                       AS vendor_no,
                inv.invoice_num                          AS invoice_no,
                "max"(inv.invoice_id)::character varying AS invoice_id,
                "min"(l.service_date)                    AS service_date,
                "max"(h.oxy_rep_name::text)              AS rep,
                "max"(h.po_number::text)                 AS bpa_number
FROM finance.ap_ap_invoices_all inv
         JOIN finance.ap_ap_suppliers suppliers ON inv.vendor_id::numeric = suppliers.vendor_id
         JOIN finance.xxoxy_oxyposshr_ft_headers h
              ON inv.invoice_num::text = h.ft_number::text AND inv.vendor_id::numeric = h.vendor_id
         JOIN finance.xxoxy_oxyposshr_ft_lines l ON h.ft_header_id = l.ft_header_id
GROUP BY suppliers.segment1, inv.invoice_num
with no schema binding;

alter table invoices
    owner to juan;

grant select on invoices to david;

