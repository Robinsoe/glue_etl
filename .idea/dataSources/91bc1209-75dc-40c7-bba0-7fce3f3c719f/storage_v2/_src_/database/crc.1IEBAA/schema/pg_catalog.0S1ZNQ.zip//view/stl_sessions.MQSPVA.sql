create view stl_sessions(userid, starttime, endtime, process, user_name, db_name) as
SELECT stll_sessions.userid,
       stll_sessions.starttime,
       stll_sessions.endtime,
       stll_sessions.process,
       stll_sessions.user_name,
       stll_sessions.db_name
FROM stll_sessions;

alter table stl_sessions
    owner to rdsdb;

