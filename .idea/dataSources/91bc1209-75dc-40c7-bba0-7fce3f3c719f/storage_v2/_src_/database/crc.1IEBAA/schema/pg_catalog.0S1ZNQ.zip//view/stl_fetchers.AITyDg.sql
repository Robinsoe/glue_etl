create view stl_fetchers (query, seg, slice, tbl, col, pid, fetcher_id, starttime, endtime, pins, faults) as
SELECT stll_fetchers.query,
       stll_fetchers.seg,
       stll_fetchers.slice,
       stll_fetchers.tbl,
       stll_fetchers.col,
       stll_fetchers.pid,
       stll_fetchers.fetcher_id,
       stll_fetchers.starttime,
       stll_fetchers.endtime,
       stll_fetchers.pins,
       stll_fetchers."faults"
FROM stll_fetchers;

alter table stl_fetchers
    owner to rdsdb;

