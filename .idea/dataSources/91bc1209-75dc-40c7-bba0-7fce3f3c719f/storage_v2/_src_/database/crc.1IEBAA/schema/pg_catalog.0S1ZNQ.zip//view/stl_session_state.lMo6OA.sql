create view stl_session_state(now, process, num_prepared_stmts, bytes_used) as
SELECT stll_session_state.now,
       stll_session_state.process,
       stll_session_state.num_prepared_stmts,
       stll_session_state.bytes_used
FROM stll_session_state;

alter table stl_session_state
    owner to rdsdb;

