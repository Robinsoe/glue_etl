create view stl_minmax_errors(logtime, query, slice, tbl, col, blocknum, error_msg) as
SELECT stll_minmax_errors.logtime,
       stll_minmax_errors.query,
       stll_minmax_errors.slice,
       stll_minmax_errors.tbl,
       stll_minmax_errors.col,
       stll_minmax_errors.blocknum,
       stll_minmax_errors.error_msg
FROM stll_minmax_errors;

alter table stl_minmax_errors
    owner to rdsdb;

