create view stl_io_stat(currenttime, sampletime, query, segment, node, reads, writes) as
SELECT stll_io_stat.currenttime,
       stll_io_stat.sampletime,
       stll_io_stat.query,
       stll_io_stat.segment,
       stll_io_stat.node,
       stll_io_stat.reads,
       stll_io_stat.writes
FROM stll_io_stat;

alter table stl_io_stat
    owner to rdsdb;

