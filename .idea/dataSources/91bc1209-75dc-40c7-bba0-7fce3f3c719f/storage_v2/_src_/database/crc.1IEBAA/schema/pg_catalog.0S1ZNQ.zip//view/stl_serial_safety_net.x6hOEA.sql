create view stl_serial_safety_net
            (xid, starttime, endtime, write_pstamp, sstamp, is_commit, ssn_serializer, cstamp, write_pstamp_oid,
             write_pstamp_updated_by_read, sstamp_oid, write_pstamp_xid, sstamp_xid, ro_pstamp, max_snapshot_time,
             ro_pstamp_oid, ro_pstamp_xid)
as
SELECT stll_serial_safety_net.xid,
       stll_serial_safety_net.starttime,
       stll_serial_safety_net.endtime,
       stll_serial_safety_net.write_pstamp,
       stll_serial_safety_net.sstamp,
       stll_serial_safety_net.is_commit,
       stll_serial_safety_net.ssn_serializer,
       stll_serial_safety_net.cstamp,
       stll_serial_safety_net.write_pstamp_oid,
       stll_serial_safety_net.write_pstamp_updated_by_read,
       stll_serial_safety_net.sstamp_oid,
       stll_serial_safety_net.write_pstamp_xid,
       stll_serial_safety_net.sstamp_xid,
       stll_serial_safety_net.ro_pstamp,
       stll_serial_safety_net.max_snapshot_time,
       stll_serial_safety_net.ro_pstamp_oid,
       stll_serial_safety_net.ro_pstamp_xid
FROM stll_serial_safety_net;

alter table stl_serial_safety_net
    owner to rdsdb;

