create view stl_alter_sortkey_events
            (userid, xid, pid, logtime, tbl_id, is_original_sortkey, num_sortkeys, sortkey_text) as
SELECT stll_alter_sortkey_events.userid,
       stll_alter_sortkey_events.xid,
       stll_alter_sortkey_events.pid,
       stll_alter_sortkey_events.logtime,
       stll_alter_sortkey_events.tbl_id,
       stll_alter_sortkey_events.is_original_sortkey,
       stll_alter_sortkey_events.num_sortkeys,
       stll_alter_sortkey_events.sortkey_text
FROM stll_alter_sortkey_events;

alter table stl_alter_sortkey_events
    owner to rdsdb;

