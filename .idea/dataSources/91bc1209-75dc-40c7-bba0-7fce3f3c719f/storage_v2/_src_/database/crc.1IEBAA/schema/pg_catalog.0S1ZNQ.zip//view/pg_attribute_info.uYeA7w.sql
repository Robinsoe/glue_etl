create view pg_attribute_info
            (attrelid, attname, atttypid, attstattarget, attlen, attnum, attndims, attcacheoff, atttypmod, attbyval,
             attstorage, attalign, attnotnull, atthasdef, attisdropped, attislocal, attinhcount, attisdistkey,
             attispreloaded, attsortkeyord, attencodingtype, attencrypttype, attacl)
as
SELECT pa.attrelid,
       pa.attname,
       pa.atttypid,
       pa.attstattarget,
       pa.attlen,
       pa.attnum,
       pa.attndims,
       pa.attcacheoff,
       pa.atttypmod,
       pa.attbyval,
       pa.attstorage,
       pa.attalign,
       pa.attnotnull,
       pa.atthasdef,
       pa.attisdropped,
       pa.attislocal,
       pa.attinhcount,
       pa.attisdistkey,
       pa.attispreloaded,
       pa.attsortkeyord,
       pa.attencodingtype,
       pa.attencrypttype,
       pac.attacl
FROM pg_attribute pa
         LEFT JOIN pg_attribute_acl pac ON pa.attrelid = pac.attrelid AND pa.attnum = pac.attnum;

alter table pg_attribute_info
    owner to rdsdb;

