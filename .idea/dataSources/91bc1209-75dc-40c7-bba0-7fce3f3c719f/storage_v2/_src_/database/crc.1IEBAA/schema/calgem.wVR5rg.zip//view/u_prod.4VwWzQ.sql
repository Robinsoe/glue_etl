create view u_prod (api12, api10, productiondate, oilorcondensateproduced, gasproduced_mcf, waterproduced_bbl) as
SELECT production_ge2018.apinumber                                      AS api12,
       "left"(production_ge2018.apinumber::text, 10)::character varying AS api10,
       production_ge2018.productionreportdate                           AS productiondate,
       sum(production_ge2018.oilorcondensateproduced)                   AS oilorcondensateproduced,
       sum(production_ge2018.gasproduced)                               AS gasproduced_mcf,
       sum(production_ge2018.waterproduced)                             AS waterproduced_bbl
FROM calgem.production_ge2018
GROUP BY production_ge2018.apinumber, production_ge2018.productionreportdate
UNION
SELECT (w.api10 || '00'::text)::character varying AS api12,
       w.api10::character varying                 AS api10,
       p.productiondate,
       sum(p.oilorcondensateproduced)             AS oilorcondensateproduced,
       sum(p.gasproduced_mcf)                     AS gasproduced_mcf,
       sum(p.waterproduced_bbl)                   AS waterproduced_bbl
FROM calgem.production_pre2018 p
         JOIN calgem.wells_pwt_map w ON w.pwt_id = p.pwt_id::numeric
WHERE pgdate_part('year'::text, p.productiondate::timestamp without time zone) < 2018::double precision
GROUP BY w.api10, p.productiondate;

alter table u_prod
    owner to crc;

