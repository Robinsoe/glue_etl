create view stl_fabric_stats(slice, query, segnum, dst, nullbytes, zerobytes) as
SELECT stll_fabric_stats.slice,
       stll_fabric_stats.query,
       stll_fabric_stats.segnum,
       stll_fabric_stats.dst,
       stll_fabric_stats.nullbytes,
       stll_fabric_stats.zerobytes
FROM stll_fabric_stats;

alter table stl_fabric_stats
    owner to rdsdb;

