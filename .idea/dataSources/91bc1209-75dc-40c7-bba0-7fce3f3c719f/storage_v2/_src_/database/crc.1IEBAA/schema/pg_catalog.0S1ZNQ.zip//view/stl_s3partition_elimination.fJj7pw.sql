create view stl_s3partition_elimination
            (userid, query, uuid, segment, node, slice, starttime, endtime, total_partitions, qualified_partitions,
             assignment, duration, assigned_partitions, scan_type, fetched_partitions)
as
SELECT stll_s3partition_elimination.userid,
       stll_s3partition_elimination.query,
       stll_s3partition_elimination.uuid,
       stll_s3partition_elimination.segment,
       stll_s3partition_elimination.node,
       stll_s3partition_elimination.slice,
       stll_s3partition_elimination.starttime,
       stll_s3partition_elimination.endtime,
       stll_s3partition_elimination.total_partitions,
       stll_s3partition_elimination.qualified_partitions,
       stll_s3partition_elimination."assignment",
       stll_s3partition_elimination.duration,
       stll_s3partition_elimination.assigned_partitions,
       stll_s3partition_elimination.scan_type,
       stll_s3partition_elimination.fetched_partitions
FROM stll_s3partition_elimination;

alter table stl_s3partition_elimination
    owner to rdsdb;

