create view stl_disk_speeds(measurement_time, node, diskno, mbps, failed) as
SELECT stll_disk_speeds.measurement_time,
       stll_disk_speeds.node,
       stll_disk_speeds.diskno,
       stll_disk_speeds.mbps,
       stll_disk_speeds.failed
FROM stll_disk_speeds;

alter table stl_disk_speeds
    owner to rdsdb;

