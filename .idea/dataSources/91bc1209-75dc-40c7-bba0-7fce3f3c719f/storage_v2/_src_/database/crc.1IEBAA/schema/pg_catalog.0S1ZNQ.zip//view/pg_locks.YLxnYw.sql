create view pg_locks(relation, database, transaction, pid, mode, granted) as
SELECT l.relation, l."database", l."transaction", l.pid, l."mode", l.granted
FROM pg_lock_status() l(relation oid, "database" oid, "transaction" xid, pid integer, "mode" character varying,
                        granted boolean);

alter table pg_locks
    owner to rdsdb;

