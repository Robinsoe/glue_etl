create view tables
            (table_catalog, table_schema, table_name, table_type, self_referencing_column_name, reference_generation,
             user_defined_type_catalog, user_defined_type_schema, user_defined_name)
as
SELECT current_database()::information_schema.sql_identifier                      AS table_catalog,
       nc.nspname::information_schema.sql_identifier                              AS table_schema,
       c.relname::information_schema.sql_identifier                               AS table_name,
       CASE
           WHEN nc.nspname ~~ like_escape('pg!_temp!_%'::text, '!'::text) THEN 'LOCAL TEMPORARY'::text
           WHEN c.relkind = 'r'::"char" THEN 'BASE TABLE'::text
           WHEN c.relkind = 'v'::"char" THEN 'VIEW'::text
           ELSE NULL::text
           END::information_schema.character_data                                 AS table_type,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS self_referencing_column_name,
       NULL::information_schema.character_data::information_schema.character_data AS reference_generation,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS user_defined_type_catalog,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS user_defined_type_schema,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS user_defined_name
FROM pg_namespace nc,
     pg_class c,
     pg_user u
WHERE c.relnamespace = nc.oid
  AND u.usesysid = c.relowner
  AND (c.relkind = 'r'::"char" OR c.relkind = 'v'::"char")
  AND (u.usename = "current_user"()::name OR has_table_privilege(c.oid, 'SELECT'::text) OR
       has_table_privilege(c.oid, 'INSERT'::text) OR has_table_privilege(c.oid, 'UPDATE'::text) OR
       has_table_privilege(c.oid, 'DELETE'::text) OR has_table_privilege(c.oid, 'RULE'::text) OR
       has_table_privilege(c.oid, 'REFERENCES'::text) OR has_table_privilege(c.oid, 'TRIGGER'::text) OR
       has_any_column_privilege(c.oid, 'SELECT'::text) OR has_any_column_privilege(c.oid, 'UPDATE'::text));

alter table tables
    owner to rdsdb;

