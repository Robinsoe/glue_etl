create view stl_wlm_rule_action
            (userid, query, service_class, rule, action, recordtime, action_value, service_class_name) as
SELECT stll_wlm_rule_action.userid,
       stll_wlm_rule_action.query,
       stll_wlm_rule_action.service_class,
       stll_wlm_rule_action."rule",
       stll_wlm_rule_action."action",
       stll_wlm_rule_action.recordtime,
       stll_wlm_rule_action.action_value,
       stll_wlm_rule_action.service_class_name
FROM stll_wlm_rule_action;

alter table stl_wlm_rule_action
    owner to rdsdb;

