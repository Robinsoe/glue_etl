create view stl_table_partitions_hotness_stats
            (eventtime, id, slice, total_wasted_blocks, total_blocks_read, total_blocks_used, no_loss_scans_count,
             zero_bias_scans_count, scan_count, num_sorted_rows, num_unsorted_rows, num_partitions, avg_qpd)
as
SELECT stll_table_partitions_hotness_stats.eventtime,
       stll_table_partitions_hotness_stats.id,
       stll_table_partitions_hotness_stats.slice,
       stll_table_partitions_hotness_stats.total_wasted_blocks,
       stll_table_partitions_hotness_stats.total_blocks_read,
       stll_table_partitions_hotness_stats.total_blocks_used,
       stll_table_partitions_hotness_stats.no_loss_scans_count,
       stll_table_partitions_hotness_stats.zero_bias_scans_count,
       stll_table_partitions_hotness_stats.scan_count,
       stll_table_partitions_hotness_stats.num_sorted_rows,
       stll_table_partitions_hotness_stats.num_unsorted_rows,
       stll_table_partitions_hotness_stats.num_partitions,
       stll_table_partitions_hotness_stats.avg_qpd
FROM stll_table_partitions_hotness_stats;

alter table stl_table_partitions_hotness_stats
    owner to rdsdb;

