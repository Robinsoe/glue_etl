create view stl_s3client_trace
            (userid, query, slice, recordtime, pid, http_method, s3_action, bucket, key, message, node, table_id,
             one_perm_rep, flags, s3_write_type, is_s3commit_write)
as
SELECT stll_s3client_trace.userid,
       stll_s3client_trace.query,
       stll_s3client_trace.slice,
       stll_s3client_trace.recordtime,
       stll_s3client_trace.pid,
       stll_s3client_trace.http_method,
       stll_s3client_trace.s3_action,
       stll_s3client_trace.bucket,
       stll_s3client_trace."key",
       stll_s3client_trace.message,
       stll_s3client_trace.node,
       stll_s3client_trace.table_id,
       stll_s3client_trace.one_perm_rep,
       stll_s3client_trace.flags,
       stll_s3client_trace.s3_write_type,
       stll_s3client_trace.is_s3commit_write
FROM stll_s3client_trace;

alter table stl_s3client_trace
    owner to rdsdb;

