create procedure mv_sp__mv_tbldatahistory__0_1(start_xid bigint, end_xid bigint, recompute boolean, finished_xid_list character varying)
    language plpgsql
as
$$
BEGIN CREATE TABLE xspoc_high_res_views.mv_tbl__mv_tbldatahistory__0__tmp BACKUP YES AS (
SELECT nodeid , date , address , value , partition_1 xspoc_source , max(partition_2) p_2
FROM xspoc_high_res.tbldatahistory
GROUP BY address, nodeid, value, date, partition_1);CREATE OR REPLACE VIEW  xspoc_high_res_views.mv_tbldatahistory AS SELECT * FROM xspoc_high_res_views.mv_tbl__mv_tbldatahistory__0__tmp;DROP TABLE xspoc_high_res_views.mv_tbl__mv_tbldatahistory__0;ALTER TABLE xspoc_high_res_views.mv_tbl__mv_tbldatahistory__0__tmp RENAME TO mv_tbl__mv_tbldatahistory__0;CREATE OR REPLACE VIEW xspoc_high_res_views.mv_tbldatahistory AS SELECT * FROM xspoc_high_res_views.mv_tbl__mv_tbldatahistory__0; END;
$$;

