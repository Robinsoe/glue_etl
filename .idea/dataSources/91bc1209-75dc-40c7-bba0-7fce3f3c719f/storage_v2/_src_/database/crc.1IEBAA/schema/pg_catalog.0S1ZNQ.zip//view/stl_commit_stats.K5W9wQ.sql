create view stl_commit_stats
            (xid, node, startqueue, startwork, endflush, endstage, endlocal, startglobal, endtime, queuelen, permblocks,
             newblocks, dirtyblocks, tombstonedblocks, tossedblocks, headers, numxids, oldestxid, extwritelatency,
             metadatawritten, batched_by)
as
SELECT stll_commit_stats.xid,
       stll_commit_stats.node,
       stll_commit_stats.startqueue,
       stll_commit_stats.startwork,
       stll_commit_stats.endflush,
       stll_commit_stats.endstage,
       stll_commit_stats.endlocal,
       stll_commit_stats.startglobal,
       stll_commit_stats.endtime,
       stll_commit_stats.queuelen,
       stll_commit_stats.permblocks,
       stll_commit_stats.newblocks,
       stll_commit_stats.dirtyblocks,
       stll_commit_stats.tombstonedblocks,
       stll_commit_stats.tossedblocks,
       stll_commit_stats.headers,
       stll_commit_stats.numxids,
       stll_commit_stats.oldestxid,
       stll_commit_stats.extwritelatency,
       stll_commit_stats.metadatawritten,
       stll_commit_stats.batched_by
FROM stll_commit_stats;

alter table stl_commit_stats
    owner to rdsdb;

