create view stl_unload_log
            (userid, query, slice, pid, path, start_time, end_time, line_count, transfer_size, file_format) as
SELECT stll_unload_log.userid,
       stll_unload_log.query,
       stll_unload_log.slice,
       stll_unload_log.pid,
       stll_unload_log."path",
       stll_unload_log.start_time,
       stll_unload_log.end_time,
       stll_unload_log.line_count,
       stll_unload_log.transfer_size,
       stll_unload_log.file_format
FROM stll_unload_log;

alter table stl_unload_log
    owner to rdsdb;

