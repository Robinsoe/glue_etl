create view stl_query_tx_metrics
            (query, userid, pid, xid, starttime, endtime, time_spent_sending_micros, num_bytes_sent, num_rows_sent) as
SELECT stll_query_tx_metrics.query,
       stll_query_tx_metrics.userid,
       stll_query_tx_metrics.pid,
       stll_query_tx_metrics.xid,
       stll_query_tx_metrics.starttime,
       stll_query_tx_metrics.endtime,
       stll_query_tx_metrics.time_spent_sending_micros,
       stll_query_tx_metrics.num_bytes_sent,
       stll_query_tx_metrics.num_rows_sent
FROM stll_query_tx_metrics;

alter table stl_query_tx_metrics
    owner to rdsdb;

