create view stl_commit_internal_stats
            (xid, node, prefetchesskipped, numreadsprocessed, numacksprocessed, tablebasedtosseligible, lastackwaittime,
             processtime, log_based, log_based_flags, index_log_regenerated, tables_total, tables_swept, headers_swept,
             tables_changed, blocks_pending_write, num_metadata_blocks_retained, total_metadata_blocks, sb_size,
             num_modified_hdrs_tracked, sb_sweep_tracking, sb_version)
as
SELECT stll_commit_internal_stats.xid,
       stll_commit_internal_stats.node,
       stll_commit_internal_stats.prefetchesskipped,
       stll_commit_internal_stats.numreadsprocessed,
       stll_commit_internal_stats.numacksprocessed,
       stll_commit_internal_stats.tablebasedtosseligible,
       stll_commit_internal_stats.lastackwaittime,
       stll_commit_internal_stats.processtime,
       stll_commit_internal_stats.log_based,
       stll_commit_internal_stats.log_based_flags,
       stll_commit_internal_stats.index_log_regenerated,
       stll_commit_internal_stats.tables_total,
       stll_commit_internal_stats.tables_swept,
       stll_commit_internal_stats.headers_swept,
       stll_commit_internal_stats.tables_changed,
       stll_commit_internal_stats.blocks_pending_write,
       stll_commit_internal_stats.num_metadata_blocks_retained,
       stll_commit_internal_stats.total_metadata_blocks,
       stll_commit_internal_stats.sb_size,
       stll_commit_internal_stats.num_modified_hdrs_tracked,
       stll_commit_internal_stats.sb_sweep_tracking,
       stll_commit_internal_stats.sb_version
FROM stll_commit_internal_stats;

alter table stl_commit_internal_stats
    owner to rdsdb;

