create view stl_query_concurrency_scaling_decision(query, table_id, xact_version, suitable_sb_version, decision_msg) as
SELECT stll_query_concurrency_scaling_decision.query,
       stll_query_concurrency_scaling_decision.table_id,
       stll_query_concurrency_scaling_decision.xact_version,
       stll_query_concurrency_scaling_decision.suitable_sb_version,
       stll_query_concurrency_scaling_decision.decision_msg
FROM stll_query_concurrency_scaling_decision;

alter table stl_query_concurrency_scaling_decision
    owner to rdsdb;

