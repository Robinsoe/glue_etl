create view stl_vacuum_detail
            (userid, query, slice, part, start_row, end_row, num_new_rows, num_blocks_replaced, total_block_io_estimate,
             window_num, num_deleted_rows, compact, num_new_blocks, empty_space_size, table_partition_number,
             local_to_total_ratio, local_block_count, insufficient_local_blk_cnt)
as
SELECT stll_vacuum_detail.userid,
       stll_vacuum_detail.query,
       stll_vacuum_detail.slice,
       stll_vacuum_detail.part,
       stll_vacuum_detail.start_row,
       stll_vacuum_detail.end_row,
       stll_vacuum_detail.num_new_rows,
       stll_vacuum_detail.num_blocks_replaced,
       stll_vacuum_detail.total_block_io_estimate,
       stll_vacuum_detail.window_num,
       stll_vacuum_detail.num_deleted_rows,
       stll_vacuum_detail.compact,
       stll_vacuum_detail.num_new_blocks,
       stll_vacuum_detail.empty_space_size,
       stll_vacuum_detail.table_partition_number,
       stll_vacuum_detail.local_to_total_ratio,
       stll_vacuum_detail.local_block_count,
       stll_vacuum_detail.insufficient_local_blk_cnt
FROM stll_vacuum_detail;

alter table stl_vacuum_detail
    owner to rdsdb;

