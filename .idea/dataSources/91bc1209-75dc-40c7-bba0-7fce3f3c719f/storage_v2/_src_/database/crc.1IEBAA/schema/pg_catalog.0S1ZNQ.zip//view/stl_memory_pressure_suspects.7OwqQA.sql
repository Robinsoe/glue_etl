create view stl_memory_pressure_suspects (now, node, state, query, shared_mem_used, heap_mem_used, num_blocks_pinned) as
SELECT stll_memory_pressure_suspects.now,
       stll_memory_pressure_suspects.node,
       stll_memory_pressure_suspects.state,
       stll_memory_pressure_suspects.query,
       stll_memory_pressure_suspects.shared_mem_used,
       stll_memory_pressure_suspects.heap_mem_used,
       stll_memory_pressure_suspects.num_blocks_pinned
FROM stll_memory_pressure_suspects;

alter table stl_memory_pressure_suspects
    owner to rdsdb;

