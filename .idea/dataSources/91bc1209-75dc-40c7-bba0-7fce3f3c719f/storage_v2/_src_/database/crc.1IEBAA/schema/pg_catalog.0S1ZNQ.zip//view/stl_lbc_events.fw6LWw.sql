create view stl_lbc_events(timestamp, xid, process, pid, node, is_error, context, message) as
SELECT stll_lbc_events."timestamp",
       stll_lbc_events.xid,
       stll_lbc_events.process,
       stll_lbc_events.pid,
       stll_lbc_events.node,
       stll_lbc_events.is_error,
       stll_lbc_events.context,
       stll_lbc_events.message
FROM stll_lbc_events;

alter table stl_lbc_events
    owner to rdsdb;

