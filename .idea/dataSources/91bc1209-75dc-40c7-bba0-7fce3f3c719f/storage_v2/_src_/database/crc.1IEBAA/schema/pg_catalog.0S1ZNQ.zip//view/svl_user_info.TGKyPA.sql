create view svl_user_info
            (usename, usesysid, usecreatedb, usesuper, usecatupd, useconnlimit, syslogaccess, last_ddl_ts) as
SELECT pg_shadow.usename::character varying AS usename,
       pg_shadow.usesysid,
       pg_shadow.usecreatedb,
       pg_shadow.usesuper,
       pg_shadow.usecatupd,
       CASE
           WHEN pse_col1.value = -1::text THEN 'UNLIMITED'::text
           ELSE pse_col1.value
           END::character varying           AS useconnlimit,
       CASE
           WHEN pse_col2.value = -1::text OR pg_shadow.usesuper = true THEN 'UNRESTRICTED'::text
           ELSE 'RESTRICTED'::text
           END::character varying           AS syslogaccess,
       stl_userlog.recordtime               AS last_ddl_ts
FROM pg_shadow
         LEFT JOIN pg_shadow_extended pse_col1 ON pg_shadow.usesysid = pse_col1."sysid" AND pse_col1.colnum = 1
         LEFT JOIN pg_shadow_extended pse_col2 ON pg_shadow.usesysid = pse_col2."sysid" AND pse_col2.colnum = 2
         LEFT JOIN (SELECT stl_userlog.userid, "max"(stl_userlog.recordtime) AS recordtime
                    FROM stl_userlog
                    GROUP BY stl_userlog.userid) stl_userlog ON stl_userlog.userid = pg_shadow.usesysid
WHERE pg_shadow.usesysid > 1;

alter table svl_user_info
    owner to rdsdb;

