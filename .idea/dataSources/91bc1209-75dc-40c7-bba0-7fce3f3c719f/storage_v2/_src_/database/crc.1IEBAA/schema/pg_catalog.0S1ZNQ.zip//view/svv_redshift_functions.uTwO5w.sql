create view svv_redshift_functions
            (database_name, schema_name, function_name, function_type, argument_type, result_type) as
SELECT current_database()::character varying(128)                                        AS database_name,
       pns.nspname::character varying(128)                                               AS schema_name,
       pgp.proname::character varying(128)                                               AS function_name,
       CASE
           WHEN pgp.prorettype = 0::oid THEN 'STORED PROCEDURE'::text
           WHEN pgp.proisagg THEN 'AGGREGATED FUNCTION'::text
           ELSE 'REGULAR FUNCTION'::text
           END::character varying                                                        AS function_type,
       oidvectortypes(pgp.proargtypes)::character varying                                AS argument_type,
       (
               CASE
                   WHEN pgp.proretset THEN 'setof '::text
                   ELSE ''::text
                   END || format_type(pgp.prorettype, NULL::integer))::character varying AS result_type
FROM pg_proc pgp
         LEFT JOIN pg_namespace pns ON pgp.pronamespace = pns.oid
WHERE has_schema_privilege("current_user"()::name, pns.oid, 'USAGE'::text)
  AND has_function_privilege(pgp.oid, 'EXECUTE'::text)
  AND pns.nspname <> 'pg_toast'::name
  AND pns.nspname <> 'pg_internal'::name
UNION ALL
SELECT btrim(rs_functions.database_name::text)::character varying(128) AS database_name,
       btrim(rs_functions.schema_name::text)::character varying(128)   AS schema_name,
       btrim(rs_functions.function_name::text)::character varying(128) AS function_name,
       btrim(rs_functions.function_type::text)::character varying(128) AS function_type,
       btrim(rs_functions.argument_type::text)::character varying(512) AS argument_type,
       btrim(rs_functions.result_type::text)::character varying(128)   AS result_type
FROM pg_get_shared_redshift_functions() rs_functions(database_name character varying, schema_name character varying,
                                                     function_name character varying, function_type character varying,
                                                     argument_type character varying, result_type character varying);

alter table svv_redshift_functions
    owner to rdsdb;

