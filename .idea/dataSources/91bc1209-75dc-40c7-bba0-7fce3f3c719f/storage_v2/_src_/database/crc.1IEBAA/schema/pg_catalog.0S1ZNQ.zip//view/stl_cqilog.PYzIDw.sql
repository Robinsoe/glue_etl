create view stl_cqilog(logtime, action, reason) as
SELECT stll_cqilog.logtime, stll_cqilog."action", stll_cqilog.reason
FROM stll_cqilog;

alter table stl_cqilog
    owner to rdsdb;

