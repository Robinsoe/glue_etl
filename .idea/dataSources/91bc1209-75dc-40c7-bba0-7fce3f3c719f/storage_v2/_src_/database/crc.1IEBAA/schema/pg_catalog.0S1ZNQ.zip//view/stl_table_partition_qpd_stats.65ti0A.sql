create view stl_table_partition_qpd_stats
            (eventtime, id, slice, partition_id, sort_key_col, blocks_read, blocks_used, rows_read, rows_used,
             bias_factor, query) as
SELECT stll_table_partition_qpd_stats.eventtime,
       stll_table_partition_qpd_stats.id,
       stll_table_partition_qpd_stats.slice,
       stll_table_partition_qpd_stats.partition_id,
       stll_table_partition_qpd_stats.sort_key_col,
       stll_table_partition_qpd_stats.blocks_read,
       stll_table_partition_qpd_stats.blocks_used,
       stll_table_partition_qpd_stats.rows_read,
       stll_table_partition_qpd_stats.rows_used,
       stll_table_partition_qpd_stats.bias_factor,
       stll_table_partition_qpd_stats.query
FROM stll_table_partition_qpd_stats;

alter table stl_table_partition_qpd_stats
    owner to rdsdb;

