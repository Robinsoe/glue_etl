create view stl_s3client_error
            (userid, query, sliceid, recordtime, pid, http_method, s3_action, bucket, key, error, retry_count,
             curl_code, start_time, resolve_time, connect_time, transfer_size, node, table_id, one_perm_rep, flags,
             s3_write_type, is_s3commit_write)
as
SELECT stll_s3client_error.userid,
       stll_s3client_error.query,
       stll_s3client_error.sliceid,
       stll_s3client_error.recordtime,
       stll_s3client_error.pid,
       stll_s3client_error.http_method,
       stll_s3client_error.s3_action,
       stll_s3client_error.bucket,
       stll_s3client_error."key",
       stll_s3client_error.error,
       stll_s3client_error.retry_count,
       stll_s3client_error.curl_code,
       stll_s3client_error.start_time,
       stll_s3client_error.resolve_time,
       stll_s3client_error.connect_time,
       stll_s3client_error.transfer_size,
       stll_s3client_error.node,
       stll_s3client_error.table_id,
       stll_s3client_error.one_perm_rep,
       stll_s3client_error.flags,
       stll_s3client_error.s3_write_type,
       stll_s3client_error.is_s3commit_write
FROM stll_s3client_error;

alter table stl_s3client_error
    owner to rdsdb;

