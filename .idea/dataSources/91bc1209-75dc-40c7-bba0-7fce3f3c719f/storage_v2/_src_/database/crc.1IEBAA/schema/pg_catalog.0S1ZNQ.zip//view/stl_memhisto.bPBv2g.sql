create view stl_memhisto
            (recordtime, node, two, four, eight, sixteen, thirtytwo, sixtyfour, onetwentyeight, twofiftysix, fivetwelve,
             onekb, twokb, fourkb, eightkb, sixteenkb, thirtytwokb, sixtyfourkb, onetwentyeightkb, twofiftysixkb,
             fivetwelvekb, onemb, twomb, fourmb, eightmb, sixteenmb, thirtytwomb, sixtyfourmb, onetwentyeightmb,
             twofiftysixmb, fivetwelvemb, onegb, twogb)
as
SELECT stll_memhisto.recordtime,
       stll_memhisto.node,
       stll_memhisto.two,
       stll_memhisto.four,
       stll_memhisto.eight,
       stll_memhisto.sixteen,
       stll_memhisto.thirtytwo,
       stll_memhisto.sixtyfour,
       stll_memhisto.onetwentyeight,
       stll_memhisto.twofiftysix,
       stll_memhisto.fivetwelve,
       stll_memhisto.onekb,
       stll_memhisto.twokb,
       stll_memhisto.fourkb,
       stll_memhisto.eightkb,
       stll_memhisto.sixteenkb,
       stll_memhisto.thirtytwokb,
       stll_memhisto.sixtyfourkb,
       stll_memhisto.onetwentyeightkb,
       stll_memhisto.twofiftysixkb,
       stll_memhisto.fivetwelvekb,
       stll_memhisto.onemb,
       stll_memhisto.twomb,
       stll_memhisto.fourmb,
       stll_memhisto.eightmb,
       stll_memhisto.sixteenmb,
       stll_memhisto.thirtytwomb,
       stll_memhisto.sixtyfourmb,
       stll_memhisto.onetwentyeightmb,
       stll_memhisto.twofiftysixmb,
       stll_memhisto.fivetwelvemb,
       stll_memhisto.onegb,
       stll_memhisto.twogb
FROM stll_memhisto;

alter table stl_memhisto
    owner to rdsdb;

