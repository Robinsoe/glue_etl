create view stl_netmon_mac
            (tn, sn, ts, inter, ip, pin, bin, bout, pout, unk, norcvbuf, noxmtbuf, out_errs, in_errs, out_drops,
             in_drops, out_colls, rbytes_rate, obytes_rate, smpl_t)
as
SELECT stll_netmon_mac.tn,
       stll_netmon_mac.sn,
       stll_netmon_mac."ts",
       stll_netmon_mac.inter,
       stll_netmon_mac.ip,
       stll_netmon_mac.pin,
       stll_netmon_mac.bin,
       stll_netmon_mac.bout,
       stll_netmon_mac.pout,
       stll_netmon_mac.unk,
       stll_netmon_mac.norcvbuf,
       stll_netmon_mac.noxmtbuf,
       stll_netmon_mac.out_errs,
       stll_netmon_mac.in_errs,
       stll_netmon_mac.out_drops,
       stll_netmon_mac.in_drops,
       stll_netmon_mac.out_colls,
       stll_netmon_mac.rbytes_rate,
       stll_netmon_mac.obytes_rate,
       stll_netmon_mac.smpl_t
FROM stll_netmon_mac;

alter table stl_netmon_mac
    owner to rdsdb;

