create view stl_datashare_changes_producer
            (userid, username, xid, pid, initial_query_time, actiontime, action, shareid, sharename, dbid, dbname,
             targetroletype, targetroleid, targetrolename, datashareobjtype, datashareobjid, datashareobjname,
             consumeraccount, consumernamespace, shareproperty, sharepropvalue, status, message)
as
SELECT stll_datashare_changes_producer.userid,
       stll_datashare_changes_producer.username,
       stll_datashare_changes_producer.xid,
       stll_datashare_changes_producer.pid,
       stll_datashare_changes_producer.initial_query_time,
       stll_datashare_changes_producer.actiontime,
       stll_datashare_changes_producer."action",
       stll_datashare_changes_producer.shareid,
       stll_datashare_changes_producer.sharename,
       stll_datashare_changes_producer.dbid,
       stll_datashare_changes_producer.dbname,
       stll_datashare_changes_producer.targetroletype,
       stll_datashare_changes_producer.targetroleid,
       stll_datashare_changes_producer.targetrolename,
       stll_datashare_changes_producer.datashareobjtype,
       stll_datashare_changes_producer.datashareobjid,
       stll_datashare_changes_producer.datashareobjname,
       stll_datashare_changes_producer.consumeraccount,
       stll_datashare_changes_producer.consumernamespace,
       stll_datashare_changes_producer.shareproperty,
       stll_datashare_changes_producer.sharepropvalue,
       stll_datashare_changes_producer.status,
       stll_datashare_changes_producer.message
FROM stll_datashare_changes_producer;

alter table stl_datashare_changes_producer
    owner to rdsdb;

