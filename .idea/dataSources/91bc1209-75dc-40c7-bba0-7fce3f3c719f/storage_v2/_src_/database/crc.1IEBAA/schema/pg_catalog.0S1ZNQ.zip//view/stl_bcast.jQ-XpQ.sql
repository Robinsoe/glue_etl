create view stl_bcast (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, packets) as
SELECT stll_bcast.userid,
       stll_bcast.query,
       stll_bcast.slice,
       stll_bcast.segment,
       stll_bcast.step,
       stll_bcast.starttime,
       stll_bcast.endtime,
       stll_bcast.tasknum,
       stll_bcast."rows",
       stll_bcast.bytes,
       stll_bcast.packets
FROM stll_bcast;

alter table stl_bcast
    owner to rdsdb;

