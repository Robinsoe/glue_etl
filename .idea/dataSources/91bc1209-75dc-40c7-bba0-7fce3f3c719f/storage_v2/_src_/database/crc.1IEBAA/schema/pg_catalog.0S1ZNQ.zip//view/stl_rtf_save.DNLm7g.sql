create view stl_rtf_save(userid, query, segment, step, hash_segment, hash_step) as
SELECT stll_rtf_save.userid,
       stll_rtf_save.query,
       stll_rtf_save.segment,
       stll_rtf_save.step,
       stll_rtf_save.hash_segment,
       stll_rtf_save.hash_step
FROM stll_rtf_save;

alter table stl_rtf_save
    owner to rdsdb;

