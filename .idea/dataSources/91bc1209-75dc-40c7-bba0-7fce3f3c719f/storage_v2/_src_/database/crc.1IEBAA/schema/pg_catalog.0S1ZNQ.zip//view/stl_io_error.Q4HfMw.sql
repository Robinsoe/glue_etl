create view stl_io_error (recordtime, pid, node, diskno, type, io_offset, nbytes, result, sys_errno, error_string) as
SELECT stll_io_error.recordtime,
       stll_io_error.pid,
       stll_io_error.node,
       stll_io_error.diskno,
       stll_io_error."type",
       stll_io_error.io_offset,
       stll_io_error.nbytes,
       stll_io_error."result",
       stll_io_error.sys_errno,
       stll_io_error.error_string
FROM stll_io_error;

alter table stl_io_error
    owner to rdsdb;

