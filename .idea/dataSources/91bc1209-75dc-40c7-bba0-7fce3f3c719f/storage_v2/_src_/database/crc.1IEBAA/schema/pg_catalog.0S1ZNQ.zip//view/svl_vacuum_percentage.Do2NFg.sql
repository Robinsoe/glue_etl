create view svl_vacuum_percentage(xid, table_id, percentage) as
SELECT s.xid,
       s.table_id,
       CASE
           WHEN s.original_blocks = 0 THEN NULL::bigint
           ELSE f."blocks" * 100 / s.original_blocks
           END AS percentage
FROM (SELECT stl_vacuum.xid, stl_vacuum.table_id, sum(stl_vacuum."blocks") AS original_blocks
      FROM stl_vacuum
      WHERE stl_vacuum.status = 'Started'::bpchar
      GROUP BY stl_vacuum.xid, stl_vacuum.table_id) s,
     (SELECT v.xid, v.table_id, sum(v."blocks") AS "blocks"
      FROM stl_vacuum v
      WHERE v.status = 'Finished'::bpchar
      GROUP BY v.xid, v.table_id) f
WHERE s.xid = f.xid
  AND s.table_id = f.table_id
ORDER BY s.xid, s.table_id;

alter table svl_vacuum_percentage
    owner to rdsdb;

