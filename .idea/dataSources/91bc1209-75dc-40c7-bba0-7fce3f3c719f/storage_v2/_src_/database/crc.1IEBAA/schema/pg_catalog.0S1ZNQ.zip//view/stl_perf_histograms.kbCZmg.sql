create view stl_perf_histograms
            (now, since, name, mean, stdev, ten_us, hundred_us, one_ms, ten_ms, hundred_ms, one_s, ten_s, inf, min, max,
             total, sum, node)
as
SELECT stll_perf_histograms.now,
       stll_perf_histograms.since,
       stll_perf_histograms.name,
       stll_perf_histograms.mean,
       stll_perf_histograms.stdev,
       stll_perf_histograms.ten_us,
       stll_perf_histograms.hundred_us,
       stll_perf_histograms.one_ms,
       stll_perf_histograms.ten_ms,
       stll_perf_histograms.hundred_ms,
       stll_perf_histograms.one_s,
       stll_perf_histograms.ten_s,
       stll_perf_histograms.inf,
       stll_perf_histograms.min,
       stll_perf_histograms."max",
       stll_perf_histograms.total,
       stll_perf_histograms.sum,
       stll_perf_histograms.node
FROM stll_perf_histograms;

alter table stl_perf_histograms
    owner to rdsdb;

