create view stl_spectrum_cache_error (query, cache_key, eventtime, error_id, error_details, system_error, request_id) as
SELECT stll_spectrum_cache_error.query,
       stll_spectrum_cache_error.cache_key,
       stll_spectrum_cache_error.eventtime,
       stll_spectrum_cache_error.error_id,
       stll_spectrum_cache_error.error_details,
       stll_spectrum_cache_error.system_error,
       stll_spectrum_cache_error.request_id
FROM stll_spectrum_cache_error;

alter table stl_spectrum_cache_error
    owner to rdsdb;

