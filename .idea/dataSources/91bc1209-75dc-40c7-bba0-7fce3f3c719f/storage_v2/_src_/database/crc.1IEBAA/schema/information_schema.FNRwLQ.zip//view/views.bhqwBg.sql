create view views
            (table_catalog, table_schema, table_name, view_definition, check_option, is_updatable,
             is_insertable_into) as
SELECT current_database()::information_schema.sql_identifier                        AS table_catalog,
       nc.nspname::information_schema.sql_identifier                                AS table_schema,
       c.relname::information_schema.sql_identifier                                 AS table_name,
       CASE
           WHEN u.usename = "current_user"()::name THEN pg_get_viewdef(c.oid)
           ELSE NULL::text
           END::information_schema.character_data                                   AS view_definition,
       'NONE'::information_schema.character_data::information_schema.character_data AS check_option,
       NULL::information_schema.character_data::information_schema.character_data   AS is_updatable,
       NULL::information_schema.character_data::information_schema.character_data   AS is_insertable_into
FROM pg_namespace nc,
     pg_class c,
     pg_user u
WHERE c.relnamespace = nc.oid
  AND u.usesysid = c.relowner
  AND c.relkind = 'v'::"char"
  AND (u.usename = "current_user"()::name OR has_table_privilege(c.oid, 'SELECT'::text) OR
       has_table_privilege(c.oid, 'INSERT'::text) OR has_table_privilege(c.oid, 'UPDATE'::text) OR
       has_table_privilege(c.oid, 'DELETE'::text) OR has_table_privilege(c.oid, 'RULE'::text) OR
       has_table_privilege(c.oid, 'REFERENCES'::text) OR has_table_privilege(c.oid, 'TRIGGER'::text) OR
       has_any_column_privilege(c.oid, 'SELECT'::text) OR has_any_column_privilege(c.oid, 'UPDATE'::text));

alter table views
    owner to rdsdb;

