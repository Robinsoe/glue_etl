create view stl_smfaults_cleared(seq, run, recordtime, msg, resolution) as
SELECT stll_smfaults_cleared.seq,
       stll_smfaults_cleared.run,
       stll_smfaults_cleared.recordtime,
       stll_smfaults_cleared.msg,
       stll_smfaults_cleared.resolution
FROM stll_smfaults_cleared;

alter table stl_smfaults_cleared
    owner to rdsdb;

