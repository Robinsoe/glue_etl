create view svl_awsclient_error(userid, query, slice, recordtime, pid, http_method, endpoint, error) as
SELECT stl_awsclient_error.userid,
       stl_awsclient_error.query,
       stl_awsclient_error.slice,
       stl_awsclient_error.recordtime,
       stl_awsclient_error.pid,
       stl_awsclient_error.http_method,
       stl_awsclient_error.endpoint,
       stl_awsclient_error.error
FROM stl_awsclient_error;

alter table svl_awsclient_error
    owner to rdsdb;

