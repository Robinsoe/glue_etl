create view stl_commit_regions(node, commit_time, sb_ver, xid, region_begin, region_end) as
SELECT stll_commit_regions.node,
       stll_commit_regions.commit_time,
       stll_commit_regions.sb_ver,
       stll_commit_regions.xid,
       stll_commit_regions.region_begin,
       stll_commit_regions.region_end
FROM stll_commit_regions;

alter table stl_commit_regions
    owner to rdsdb;

