create view stl_command_start(commandtime, command, args) as
SELECT stll_command_start.commandtime, stll_command_start.command, stll_command_start.args
FROM stll_command_start;

alter table stl_command_start
    owner to rdsdb;

