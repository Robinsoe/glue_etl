create view stl_client_write_timings(node, instance, write_size, request_write, round_trip) as
SELECT stll_client_write_timings.node,
       stll_client_write_timings.instance,
       stll_client_write_timings.write_size,
       stll_client_write_timings.request_write,
       stll_client_write_timings.round_trip
FROM stll_client_write_timings;

alter table stl_client_write_timings
    owner to rdsdb;

