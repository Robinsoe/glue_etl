create view finods_hyperion_account
            (hyperion_acct_cd, hyperion_acct_cd_short, hyperion_name, hyperion_desc, line_no, subtract_flag,
             hyperion_scope) as
SELECT xxoxycommon_oxycmnshr_hyperion_account.hyperion_acct_cd,
       xxoxycommon_oxycmnshr_hyperion_account.hyperion_acct_cd_short,
       xxoxycommon_oxycmnshr_hyperion_account.hyperion_name,
       xxoxycommon_oxycmnshr_hyperion_account.hyperion_desc,
       xxoxycommon_oxycmnshr_hyperion_account.line_no,
       xxoxycommon_oxycmnshr_hyperion_account.subtract_flag,
       xxoxycommon_oxycmnshr_hyperion_account.hyperion_scope
FROM xxoxycommon_oxycmnshr_hyperion_account
WHERE xxoxycommon_oxycmnshr_hyperion_account.status::text = 'A'::character varying::text;

alter table finods_hyperion_account
    owner to crc;

grant select on finods_hyperion_account to juan;

grant select on finods_hyperion_account to david;

grant select on finods_hyperion_account to isabel;

