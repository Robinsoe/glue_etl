create view svl_spatial_simplify
            (query, line_number, maximum_tolerance, initial_size, simplified, final_size, final_tolerance) as
SELECT stl_spatial_simplify.query,
       stl_spatial_simplify.line_number,
       stl_spatial_simplify.maximum_tolerance::character varying::double precision AS maximum_tolerance,
       stl_spatial_simplify.initial_size,
       stl_spatial_simplify.simplified,
       stl_spatial_simplify.final_size,
       stl_spatial_simplify.final_tolerance::character varying::double precision   AS final_tolerance
FROM stl_spatial_simplify;

alter table svl_spatial_simplify
    owner to rdsdb;

