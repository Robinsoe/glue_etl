create view stl_server_write_timings(node, instance, write_size, wait_for_data, collect_data, iolocal) as
SELECT stll_server_write_timings.node,
       stll_server_write_timings.instance,
       stll_server_write_timings.write_size,
       stll_server_write_timings.wait_for_data,
       stll_server_write_timings.collect_data,
       stll_server_write_timings.iolocal
FROM stll_server_write_timings;

alter table stl_server_write_timings
    owner to rdsdb;

