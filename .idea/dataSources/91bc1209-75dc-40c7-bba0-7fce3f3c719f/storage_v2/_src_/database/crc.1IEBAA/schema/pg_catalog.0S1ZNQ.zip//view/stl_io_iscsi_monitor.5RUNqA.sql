create view stl_io_iscsi_monitor(event_time, node, type, event) as
SELECT stll_io_iscsi_monitor.event_time,
       stll_io_iscsi_monitor.node,
       stll_io_iscsi_monitor."type",
       stll_io_iscsi_monitor.event
FROM stll_io_iscsi_monitor;

alter table stl_io_iscsi_monitor
    owner to rdsdb;

