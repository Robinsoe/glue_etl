create view stl_backup_compute
            (currenttime, node_num, state, backup_id, sb_version, starttime, num_blocks, superblock_size,
             permanent_blocks, blocks_to_upload, blocks_uploaded, num_failures, num_modified_superblock_segments,
             total_num_superblock_segments, time_spent_stage1, time_spent_read_sb_header, time_spent_copy_segments,
             time_spent_stage2, time_spent_set_in_s3_bits, inc_no_backup, nobackup_blocks, distall_blocks,
             non_distall_blocks, perm_blocks_in_s3, metadata_read_from_backup, blocks_validated)
as
SELECT stll_backup_compute.currenttime,
       stll_backup_compute.node_num,
       stll_backup_compute.state,
       stll_backup_compute.backup_id,
       stll_backup_compute.sb_version,
       stll_backup_compute.starttime,
       stll_backup_compute.num_blocks,
       stll_backup_compute.superblock_size,
       stll_backup_compute.permanent_blocks,
       stll_backup_compute.blocks_to_upload,
       stll_backup_compute.blocks_uploaded,
       stll_backup_compute.num_failures,
       stll_backup_compute.num_modified_superblock_segments,
       stll_backup_compute.total_num_superblock_segments,
       stll_backup_compute.time_spent_stage1,
       stll_backup_compute.time_spent_read_sb_header,
       stll_backup_compute.time_spent_copy_segments,
       stll_backup_compute.time_spent_stage2,
       stll_backup_compute.time_spent_set_in_s3_bits,
       stll_backup_compute.inc_no_backup,
       stll_backup_compute.nobackup_blocks,
       stll_backup_compute.distall_blocks,
       stll_backup_compute.non_distall_blocks,
       stll_backup_compute.perm_blocks_in_s3,
       stll_backup_compute.metadata_read_from_backup,
       stll_backup_compute.blocks_validated
FROM stll_backup_compute;

alter table stl_backup_compute
    owner to rdsdb;

