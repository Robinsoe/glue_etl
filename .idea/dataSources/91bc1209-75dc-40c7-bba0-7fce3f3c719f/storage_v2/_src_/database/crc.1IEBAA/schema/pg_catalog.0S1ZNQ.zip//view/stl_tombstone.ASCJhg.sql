create view stl_tombstone
            (type, starttime, nodenum, toss_guc_value, total, tombstoned, tossed_min_qid, tossed_table_ref) as
SELECT stll_tombstone."type",
       stll_tombstone.starttime,
       stll_tombstone.nodenum,
       stll_tombstone.toss_guc_value,
       stll_tombstone.total,
       stll_tombstone.tombstoned,
       stll_tombstone.tossed_min_qid,
       stll_tombstone.tossed_table_ref
FROM stll_tombstone;

alter table stl_tombstone
    owner to rdsdb;

