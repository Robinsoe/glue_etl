create view svcs_unload_log (userid, query, pid, path, start_time, end_time, line_count, transfer_size, file_format) as
SELECT derived_table3.userid,
       derived_table3.query,
       derived_table3.pid,
       derived_table3."path",
       min(derived_table3.start_time)    AS start_time,
       "max"(derived_table3.end_time)    AS end_time,
       sum(derived_table3.line_count)    AS line_count,
       sum(derived_table3.transfer_size) AS transfer_size,
       derived_table3.file_format
FROM (SELECT svcs.userid,
             svcs.query,
             svcs.pid,
             svcs."path",
             svcs.start_time,
             svcs.end_time,
             svcs.line_count,
             svcs.transfer_size,
             svcs.file_format
      FROM (SELECT stcs.userid,
                   "map".primary_query  AS query,
                   stcs.pid,
                   stcs."path",
                   '1970-01-01 00:00:00'::timestamp without time zone +
                   (stcs.start_time::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
                   '00:00:01'::interval AS start_time,
                   '1970-01-01 00:00:00'::timestamp without time zone +
                   (stcs.end_time::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
                   '00:00:01'::interval AS end_time,
                   stcs.line_count,
                   stcs.transfer_size,
                   stcs.file_format
            FROM stcs_unload_log stcs
                     JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
            WHERE stcs.__cluster_type = 'cs'::bpchar
              AND to_date(stcs.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
              AND to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
              AND "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10)
              AND ((EXISTS(SELECT 1
                           FROM pg_user
                           WHERE pg_user.usename = "current_user"()::name
                             AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                                      FROM pg_shadow_extended
                                                                      WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                                        AND pg_shadow_extended.colnum = 2
                                                                        AND pg_shadow_extended.value = -1::text)) OR
                   stcs.userid = "current_user_id"())) svcs
      UNION ALL
      SELECT stl_unload_log.userid,
             stl_unload_log.query,
             stl_unload_log.pid,
             stl_unload_log."path",
             stl_unload_log.start_time,
             stl_unload_log.end_time,
             stl_unload_log.line_count,
             stl_unload_log.transfer_size,
             stl_unload_log.file_format
      FROM stl_unload_log) derived_table3
GROUP BY derived_table3.userid, derived_table3.query, derived_table3.pid, derived_table3."path",
         derived_table3.file_format;

alter table svcs_unload_log
    owner to rdsdb;

