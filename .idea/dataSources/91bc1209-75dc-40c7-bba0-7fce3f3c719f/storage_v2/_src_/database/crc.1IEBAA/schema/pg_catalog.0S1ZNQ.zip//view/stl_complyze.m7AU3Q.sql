create view stl_complyze(measuretime, node, tbl, col, encoding, size, tbl_name, col_name) as
SELECT stll_complyze.measuretime,
       stll_complyze.node,
       stll_complyze.tbl,
       stll_complyze.col,
       stll_complyze."encoding",
       stll_complyze.size,
       stll_complyze.tbl_name,
       stll_complyze.col_name
FROM stll_complyze;

alter table stl_complyze
    owner to rdsdb;

