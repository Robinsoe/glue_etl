create view stl_query
            (userid, query, label, xid, pid, database, querytxt, starttime, endtime, aborted, insert_pristine,
             concurrency_scaling_status)
as
SELECT stll_query.userid,
       stll_query.query,
       stll_query."label",
       stll_query.xid,
       stll_query.pid,
       stll_query."database",
       stll_query.querytxt,
       stll_query.starttime,
       stll_query.endtime,
       stll_query.aborted,
       stll_query.insert_pristine,
       stll_query.concurrency_scaling_status
FROM stll_query;

alter table stl_query
    owner to rdsdb;

