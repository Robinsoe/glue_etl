create view stl_return (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, packets) as
SELECT stll_return.userid,
       stll_return.query,
       stll_return.slice,
       stll_return.segment,
       stll_return.step,
       stll_return.starttime,
       stll_return.endtime,
       stll_return.tasknum,
       stll_return."rows",
       stll_return.bytes,
       stll_return.packets
FROM stll_return;

alter table stl_return
    owner to rdsdb;

