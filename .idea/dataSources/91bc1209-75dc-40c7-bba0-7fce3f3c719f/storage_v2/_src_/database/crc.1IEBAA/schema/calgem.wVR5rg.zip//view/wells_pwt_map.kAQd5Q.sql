create view wells_pwt_map(pwt_id, api10) as
SELECT DISTINCT w.pwt_id, '04'::character varying::text || w.apinumber::text AS api10
FROM calgem.wells_pre2018 w;

alter table wells_pwt_map
    owner to crc;

