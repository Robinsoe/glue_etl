create view stl_nullyze(measuretime, tbl, col, nullcount, tbl_name, col_name) as
SELECT stll_nullyze.measuretime,
       stll_nullyze.tbl,
       stll_nullyze.col,
       stll_nullyze.nullcount,
       stll_nullyze.tbl_name,
       stll_nullyze.col_name
FROM stll_nullyze;

alter table stl_nullyze
    owner to rdsdb;

