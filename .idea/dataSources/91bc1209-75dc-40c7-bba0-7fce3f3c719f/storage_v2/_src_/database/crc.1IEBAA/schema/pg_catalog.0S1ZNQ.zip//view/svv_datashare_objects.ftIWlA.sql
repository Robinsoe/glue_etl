create view svv_datashare_objects
            (share_type, share_name, object_type, object_name, producer_account, producer_namespace) as
((SELECT 'OUTBOUND'                                                                        AS share_type,
         pg_datashare.sharename::character varying(128)                                    AS share_name,
         CASE
             WHEN dso.objtype = 'r'::"char" THEN 'table'::text
             WHEN dso.objtype = 'v'::"char" THEN 'view'::text
             WHEN dso.objtype = 'l'::"char" THEN 'late binding view'::text
             WHEN dso.objtype = 'm'::"char" THEN 'materialized view'::text
             ELSE 'unknown'::text
             END::character varying(64)                                                    AS object_type,
         (((pns.nspname::text || '.'::text) || pgc.relname::text))::character varying(512) AS object_name,
         "current_aws_account"()                                                           AS producer_account,
         "current_namespace"()                                                             AS producer_namespace
  FROM pg_datashare_objects dso
           LEFT JOIN pg_datashare ON dso.shareid = pg_datashare.oid
           JOIN pg_class pgc ON dso.objid = pgc.oid
           JOIN pg_namespace pns ON pgc.relnamespace = pns.oid
  UNION ALL
  SELECT 'OUTBOUND'                                         AS share_type,
         pg_datashare.sharename::character varying(128)     AS share_name,
         'schema'::character varying::character varying(64) AS object_type,
         pns.nspname::character varying(512)                AS object_name,
         "current_aws_account"()                            AS producer_account,
         "current_namespace"()                              AS producer_namespace
  FROM pg_datashare_objects dso
           LEFT JOIN pg_datashare ON dso.shareid = pg_datashare.oid
           JOIN pg_namespace pns ON dso.objid = pns.oid)
 UNION ALL
 SELECT 'OUTBOUND'                                                                         AS share_type,
        pg_datashare.sharename::character varying(128)                                     AS share_name,
        'function'::character varying::character varying(64)                               AS object_type,
        (((pns.nspname::text || '.'::text) || proc.proname::text))::character varying(512) AS object_name,
        "current_aws_account"()                                                            AS producer_account,
        "current_namespace"()                                                              AS producer_namespace
 FROM pg_datashare_objects dso
          LEFT JOIN pg_datashare ON dso.shareid = pg_datashare.oid
          JOIN pg_proc proc ON dso.objid = proc.oid
          JOIN pg_namespace pns ON proc.pronamespace = pns.oid)
UNION ALL
SELECT 'INBOUND'                                                  AS share_type,
       incoming_objects.share_name,
       incoming_objects.object_type,
       incoming_objects.object_name,
       incoming_objects.producer_account::character varying(16)   AS producer_account,
       incoming_objects.producer_namespace::character varying(64) AS producer_namespace
FROM pg_get_inbound_datashare_objects() incoming_objects(share_name character varying, object_type character varying,
                                                         object_name character varying,
                                                         producer_account character varying,
                                                         producer_namespace character varying);

alter table svv_datashare_objects
    owner to rdsdb;

