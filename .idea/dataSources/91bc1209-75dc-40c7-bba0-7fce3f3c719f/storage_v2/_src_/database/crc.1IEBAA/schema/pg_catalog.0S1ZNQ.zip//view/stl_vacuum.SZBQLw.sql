create view stl_vacuum (userid, xid, table_id, status, rows, sortedrows, blocks, max_merge_partitions, eventtime) as
SELECT stll_vacuum.userid,
       stll_vacuum.xid,
       stll_vacuum.table_id,
       stll_vacuum.status,
       stll_vacuum."rows",
       stll_vacuum.sortedrows,
       stll_vacuum."blocks",
       stll_vacuum.max_merge_partitions,
       stll_vacuum.eventtime
FROM stll_vacuum;

alter table stl_vacuum
    owner to rdsdb;

