create view svl_query_concurrency_scaling_status
            (userid, query, xid, pid, source_query, concurrency_scaling_status, concurrency_scaling_status_txt,
             starttime, endtime) as
SELECT sq.userid,
       sq.query,
       sq.xid,
       sq.pid,
       sr.source_query,
       sq.concurrency_scaling_status,
       CASE
           WHEN sq.userid = 1 THEN 'Concurrency Scaling ineligible query - Bootstrap user query'::text
           WHEN sq.concurrency_scaling_status = 1 THEN 'Ran on a Concurrency Scaling cluster'::text
           WHEN sq.concurrency_scaling_status = 0 AND sr.source_query IS NOT NULL
               THEN 'Ran on the main cluster - Cache hit'::text
           WHEN sq.concurrency_scaling_status = 0 AND sw.service_class = 14 THEN 'Ran on the main cluster - SQA'::text
           WHEN sq.concurrency_scaling_status = 32 AND sw.service_class = 14
               THEN 'Ran on the main cluster - Concurrency scaling is not enabled in SQA'::text
           WHEN sq.concurrency_scaling_status = 0 AND (sq.query IN (SELECT stl_burst_prepare.query
                                                                    FROM stl_burst_prepare)) AND
                NOT (sq.query IN (SELECT stl_burst_prepare.query
                                  FROM stl_burst_prepare
                                  WHERE stl_burst_prepare.code = 0))
               THEN 'Concurrency Scaling elegible query - Failed to prepare cluster '::text
           WHEN sq.concurrency_scaling_status = 0 THEN 'Ran on the main cluster'::text
           WHEN sq.concurrency_scaling_status = 2 THEN 'Concurrency Scaling not enabled'::text
           WHEN sq.concurrency_scaling_status = 4
               THEN 'Concurrency Scaling ineligible query - System temporary table accessed'::text
           WHEN sq.concurrency_scaling_status = 5
               THEN 'Concurrency Scaling ineligible query - User temporary table accessed'::text
           WHEN sq.concurrency_scaling_status = 6 THEN 'Concurrency Scaling ineligible query - System table accessed'::text
           WHEN sq.concurrency_scaling_status = 3 THEN 'Concurrency Scaling ineligible query - Query is a DML'::text
           WHEN sq.concurrency_scaling_status = 7 THEN 'Concurrency Scaling ineligible query - No backup table accessed'::text
           WHEN sq.concurrency_scaling_status = 8 THEN 'Concurrency Scaling ineligible query - Zindex table accessed'::text
           WHEN sq.concurrency_scaling_status = 9 THEN 'Concurrency Scaling ineligible query - Query uses UDF'::text
           WHEN sq.concurrency_scaling_status = 10 THEN 'Concurrency Scaling ineligible query - Catalog tables accessed'::text
           WHEN sq.concurrency_scaling_status = 11 THEN 'Concurrency Scaling ineligible query - Dirty table accessed'::text
           WHEN sq.concurrency_scaling_status = 12 THEN 'Concurrency Scaling ineligible query - Direct dispatched query'::text
           WHEN sq.concurrency_scaling_status = 16 THEN 'Concurrency Scaling ineligible query - No tables accessed'::text
           WHEN sq.concurrency_scaling_status = 17
               THEN 'Concurrency Scaling ineligible query - Spectrum queries are disabled'::text
           WHEN sq.concurrency_scaling_status = 18 THEN 'Concurrency Scaling ineligible query - Function not supported '::text
           WHEN sq.concurrency_scaling_status = 19
               THEN 'Concurrency Scaling ineligible query - Instance type not supported '::text
           WHEN sq.concurrency_scaling_status = 20
               THEN 'Concurrency Scaling ineligible query - Burst temporarily disabled '::text
           WHEN sq.concurrency_scaling_status = 21
               THEN 'Concurrency Scaling ineligible query - Unload queries are disabled '::text
           WHEN sq.concurrency_scaling_status = 22
               THEN 'Concurrency Scaling ineligible query - Unsupported unload type '::text
           WHEN sq.concurrency_scaling_status = 23
               THEN 'Concurrency Scaling ineligible query - Non VPC clusters cannot burst '::text
           WHEN sq.concurrency_scaling_status = 24 THEN 'Concurrency Scaling ineligible query - VPCE not setup '::text
           WHEN sq.concurrency_scaling_status = 25
               THEN 'Concurrency Scaling failed query - Inelegible to rerun on main cluster due to failure handling not enabled'::text
           WHEN sq.concurrency_scaling_status = 26
               THEN 'Concurrency Scaling failed query - Inelegible to rerun on main cluster due to concurrency scaling not auto'::text
           WHEN sq.concurrency_scaling_status = 27
               THEN 'Concurrency Scaling failed query - Inelegible to rerun on main cluster due to results already returning '::text
           WHEN sq.concurrency_scaling_status = 28
               THEN 'Concurrency Scaling failed query - Inelegible to rerun on main cluster due to non retriable error '::text
           WHEN sq.concurrency_scaling_status = 29
               THEN 'Concurrency Scaling failed query - Elegible to rerun on main cluster '::text
           WHEN sq.concurrency_scaling_status = 30
               THEN 'Concurrency Scaling inelegible query - Cumulative time not met '::text
           WHEN sq.concurrency_scaling_status = 31 THEN 'Concurrency Scaling inelegible query - Paused query '::text
           WHEN sq.concurrency_scaling_status = 32 THEN 'Query assigned to non Concurrency Scaling queue '::text
           WHEN sq.concurrency_scaling_status = 33
               THEN 'Concurrency Scaling ineligible query - Query has state on Main cluster '::text
           WHEN sq.concurrency_scaling_status = 34
               THEN 'Concurrency Scaling ineligible query - Query is inelegible for bursting Volt CTAS '::text
           WHEN sq.concurrency_scaling_status = 35 THEN 'Concurrency Scaling ineligible query - Resource blacklisted '::text
           WHEN sq.concurrency_scaling_status = 36
               THEN 'Concurrency Scaling ineligible query - Non-retryable VoltTT queries are blacklisted '::text
           WHEN sq.concurrency_scaling_status = 37
               THEN 'Concurrency Scaling ineligible query - Query is retrying on Main cluster '::text
           WHEN sq.concurrency_scaling_status = 38
               THEN 'Concurrency Scaling ineligible query - Cannot burst Volt-created CTAS using cursors '::text
           WHEN sq.concurrency_scaling_status = 39 THEN 'Concurrency Scaling usage limit reached '::text
           WHEN sq.concurrency_scaling_status = 40
               THEN 'Concurrency Scaling ineligible query - Unsupported VoltTT Utility query '::text
           WHEN sq.concurrency_scaling_status = 41
               THEN 'Concurrency Scaling ineligible query - Write query generating Volt TTs '::text
           WHEN sq.concurrency_scaling_status = 42
               THEN 'Concurrency Scaling ineligible query - VoltTT query with invalid state '::text
           WHEN sq.concurrency_scaling_status = 43
               THEN 'Concurrency Scaling ineligible query - Explain query generating Volt TTs '::text
           WHEN sq.concurrency_scaling_status = 44
               THEN 'Concurrency Scaling ineligible query - Bursting Volt-generated queries is disabled '::text
           WHEN sq.concurrency_scaling_status = 45
               THEN 'Concurrency Scaling ineligible query - Resource of VoltTT UNLOAD is blacklisted '::text
           WHEN sq.concurrency_scaling_status = 46
               THEN 'Concurrency Scaling ineligible query - Multiple pre-Volt query trees '::text
           ELSE 'Concurrency Scaling ineligible query - Unknown status'::text
           END AS concurrency_scaling_status_txt,
       sq.starttime,
       sq.endtime
FROM stl_query sq
         LEFT JOIN stl_result_cache_history sr ON sq.query = sr.cache_hit_query
         LEFT JOIN stl_wlm_query sw ON sq.query = sw.query AND sq.userid = sw.userid AND sq.xid = sw.xid;

alter table svl_query_concurrency_scaling_status
    owner to rdsdb;

