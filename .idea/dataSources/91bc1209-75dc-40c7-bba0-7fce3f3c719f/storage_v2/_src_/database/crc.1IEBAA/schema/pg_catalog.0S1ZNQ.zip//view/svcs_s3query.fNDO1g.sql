create view svcs_s3query
            (userid, query, segment, step, node, slice, starttime, endtime, elapsed, external_table_name, file_format,
             is_partitioned, is_rrscan, is_nested, s3_scanned_rows, s3_scanned_bytes, s3query_returned_rows,
             s3query_returned_bytes, files, splits, total_split_size, max_split_size, total_retries, max_retries,
             max_request_duration, avg_request_duration, max_request_parallelism, avg_request_parallelism,
             slowdown_count, max_concurrent_slowdown_count, scan_type)
as
SELECT stcs.userid,
       "map".primary_query                                                                                  AS query,
       stcs.segment,
       stcs.step,
       stcs.node,
       stcs.slice,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.starttime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval                                                                                 AS starttime,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs.endtime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision * '00:00:01'::interval   AS endtime,
       stcs.endtime - stcs.starttime                                                                        AS elapsed,
       btrim(stcs.external_table_name::text)                                                                AS external_table_name,
       stcs.file_format,
       stcs.is_partitioned,
       stcs.is_rrscan,
       stcs.is_nested,
       stcs.s3_scanned_rows,
       stcs.s3_scanned_bytes,
       stcs.s3query_returned_rows,
       stcs.s3query_returned_bytes,
       stcs.files,
       stcs.splits,
       stcs.total_split_size,
       stcs.max_split_size,
       stcs.total_retries,
       stcs.max_retries,
       stcs.max_request_duration,
       stcs.avg_request_duration,
       stcs.max_request_parallelism,
       stcs.avg_request_parallelism,
       stcs.slowdown_count,
       stcs.max_concurrent_slowdown_count,
       stcs.scan_type
FROM stcs_s3query stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE stcs.__cluster_type = 'cs'::bpchar
  AND to_date(stcs.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND to_date("map".__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
  AND "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10)
  AND stcs.is_copy = 0
  AND ((EXISTS(SELECT 1
               FROM pg_user
               WHERE pg_user.usename = "current_user"()::name
                 AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                          FROM pg_shadow_extended
                                                          WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                            AND pg_shadow_extended.colnum = 2
                                                            AND pg_shadow_extended.value = -1::text)) OR
       stcs.userid = "current_user_id"());

alter table svcs_s3query
    owner to rdsdb;

