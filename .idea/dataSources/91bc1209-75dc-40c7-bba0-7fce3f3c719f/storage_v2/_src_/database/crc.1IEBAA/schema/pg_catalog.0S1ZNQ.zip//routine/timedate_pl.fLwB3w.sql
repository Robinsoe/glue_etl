create function timedate_pl(time without time zone, date) returns timestamp without time zone
    immutable
    language sql
as
$$
    select ($2 + $1)
$$;

comment on function timedate_pl(time, date) is 'convert time and date to timestamp';

