create view svv_redshift_databases (database_name, database_owner, database_type, database_acl, database_options) as
SELECT btrim(pgd.datname::text)::character varying(128)               AS database_name,
       pgd.datdba                                                     AS database_owner,
       CASE
           WHEN pged.dboptions IS NULL THEN 'local'::text
           ELSE 'shared'::text
           END::character varying(16)                                 AS database_type,
       array_to_string(pgd.datacl, '~'::text)::character varying(128) AS database_acl,
       pged.dboptions                                                 AS database_options
FROM pg_database pgd
         LEFT JOIN pg_external_database pged ON pgd.oid = pged.dbid
WHERE pgd.datname <> 'padb_harvest'::name
  AND pgd.datname <> 'template0'::name
  AND pgd.datname <> 'template1'::name;

alter table svv_redshift_databases
    owner to rdsdb;

