create view stl_consistency(time, type, message) as
SELECT stll_consistency."time", stll_consistency."type", stll_consistency.message
FROM stll_consistency;

alter table stl_consistency
    owner to rdsdb;

