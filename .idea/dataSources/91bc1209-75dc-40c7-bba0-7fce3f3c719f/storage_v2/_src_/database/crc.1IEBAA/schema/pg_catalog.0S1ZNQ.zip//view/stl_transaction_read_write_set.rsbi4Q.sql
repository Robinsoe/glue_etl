create view stl_transaction_read_write_set(xid, table_id, is_write) as
SELECT stll_transaction_read_write_set.xid,
       stll_transaction_read_write_set.table_id,
       stll_transaction_read_write_set.is_write
FROM stll_transaction_read_write_set;

alter table stl_transaction_read_write_set
    owner to rdsdb;

