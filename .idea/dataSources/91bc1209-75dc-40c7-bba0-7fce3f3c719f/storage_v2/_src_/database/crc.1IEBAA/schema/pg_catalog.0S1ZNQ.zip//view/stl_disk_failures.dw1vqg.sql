create view stl_disk_failures(event_time, node, host, diskno, event, err_code) as
SELECT stll_disk_failures.event_time,
       stll_disk_failures.node,
       stll_disk_failures."host",
       stll_disk_failures.diskno,
       stll_disk_failures.event,
       stll_disk_failures.err_code
FROM stll_disk_failures;

alter table stl_disk_failures
    owner to rdsdb;

