create view svl_s3retries
            (query, segment, node, slice, eventtime, retries, successful_fetches, file_size, location, message) as
SELECT stl_s3retries.query,
       stl_s3retries.segment,
       stl_s3retries.node,
       stl_s3retries.slice,
       stl_s3retries.eventtime,
       stl_s3retries.retries,
       stl_s3retries.successful_fetches,
       stl_s3retries.file_size,
       btrim(stl_s3retries."location"::text) AS "location",
       btrim(stl_s3retries.message::text)    AS message
FROM stl_s3retries;

alter table svl_s3retries
    owner to rdsdb;

