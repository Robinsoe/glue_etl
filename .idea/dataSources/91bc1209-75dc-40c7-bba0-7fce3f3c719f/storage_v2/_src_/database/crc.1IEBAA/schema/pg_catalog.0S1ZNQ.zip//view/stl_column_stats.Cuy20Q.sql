create view stl_column_stats
            (tbl, col, total_count, total_runtime, stale_count, stale_runtime, missing_count, missing_runtime,
             report_time) as
SELECT stll_column_stats.tbl,
       stll_column_stats.col,
       stll_column_stats.total_count,
       stll_column_stats.total_runtime,
       stll_column_stats.stale_count,
       stll_column_stats.stale_runtime,
       stll_column_stats.missing_count,
       stll_column_stats.missing_runtime,
       stll_column_stats.report_time
FROM stll_column_stats;

alter table stl_column_stats
    owner to rdsdb;

