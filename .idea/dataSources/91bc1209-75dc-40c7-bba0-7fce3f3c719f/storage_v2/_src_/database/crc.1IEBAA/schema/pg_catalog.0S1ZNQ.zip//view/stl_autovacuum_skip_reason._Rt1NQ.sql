create view stl_autovacuum_skip_reason (eventtime, id, slice, diststyle, vacuum_mode, num_columns, num_rows, reason) as
SELECT stll_autovacuum_skip_reason.eventtime,
       stll_autovacuum_skip_reason.id,
       stll_autovacuum_skip_reason.slice,
       stll_autovacuum_skip_reason."diststyle",
       stll_autovacuum_skip_reason.vacuum_mode,
       stll_autovacuum_skip_reason.num_columns,
       stll_autovacuum_skip_reason.num_rows,
       stll_autovacuum_skip_reason.reason
FROM stll_autovacuum_skip_reason;

alter table stl_autovacuum_skip_reason
    owner to rdsdb;

