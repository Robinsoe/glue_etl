create view stl_load_commits
            (userid, query, slice, name, filename, byte_offset, lines_scanned, errors, status, curtime, file_format) as
SELECT stll_load_commits.userid,
       stll_load_commits.query,
       stll_load_commits.slice,
       stll_load_commits.name,
       stll_load_commits.filename,
       stll_load_commits.byte_offset,
       stll_load_commits.lines_scanned,
       stll_load_commits.errors,
       stll_load_commits.status,
       stll_load_commits.curtime,
       stll_load_commits.file_format
FROM stll_load_commits;

alter table stl_load_commits
    owner to rdsdb;

