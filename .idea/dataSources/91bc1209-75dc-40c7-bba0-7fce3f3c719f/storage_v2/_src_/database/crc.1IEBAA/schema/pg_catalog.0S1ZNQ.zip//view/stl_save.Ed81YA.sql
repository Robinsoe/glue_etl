create view stl_save
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, tbl, is_diskbased, workmem,
             is_save_rtf)
as
SELECT stll_save.userid,
       stll_save.query,
       stll_save.slice,
       stll_save.segment,
       stll_save.step,
       stll_save.starttime,
       stll_save.endtime,
       stll_save.tasknum,
       stll_save."rows",
       stll_save.bytes,
       stll_save.tbl,
       stll_save.is_diskbased,
       stll_save.workmem,
       stll_save.is_save_rtf
FROM stll_save;

alter table stl_save
    owner to rdsdb;

