create view svv_query_state
            (userid, query, seg, step, maxtime, avgtime, rows, bytes, cpu, memory, rate_row, rate_byte, label,
             is_diskbased, workmem, num_parts, is_rrscan, is_delayed_scan)
as
SELECT stv_exec_state.userid,
       stv_exec_state.query,
       stv_exec_state.segment                                                                       AS seg,
       stv_exec_state.step,
       "max"(date_diff('microseconds'::text, stv_exec_state.starttime, stv_exec_state.currenttime)) AS maxtime,
       avg(date_diff('microseconds'::text, stv_exec_state.starttime, stv_exec_state.currenttime))   AS avgtime,
       sum(stv_exec_state."rows")                                                                   AS "rows",
       sum(stv_exec_state.bytes)                                                                    AS bytes,
       sum(stv_proc_stat.utime * 1000 /
           CASE
               WHEN stv_proc_stat.elapsed = 0 THEN NULL::integer
               ELSE stv_proc_stat.elapsed
               END / 10)                                                                            AS cpu,
       sum(stv_proc_stat.memory)                                                                    AS memory,
       round(sum(stv_exec_state."rows")::double precision /
             CASE
                 WHEN "date_part"('epoch'::text, "max"(stv_exec_state.currenttime - stv_exec_state.starttime)) =
                      0::double precision THEN NULL::double precision
                 ELSE "date_part"('epoch'::text, "max"(stv_exec_state.currenttime - stv_exec_state.starttime))
                 END)                                                                               AS rate_row,
       round(sum(stv_exec_state.bytes)::double precision /
             CASE
                 WHEN "date_part"('epoch'::text, "max"(stv_exec_state.currenttime - stv_exec_state.starttime)) =
                      0::double precision THEN NULL::double precision
                 ELSE "date_part"('epoch'::text, "max"(stv_exec_state.currenttime - stv_exec_state.starttime))
                 END)                                                                               AS rate_byte,
       stv_exec_state."label",
       stv_exec_state.is_diskbased,
       sum(stv_exec_state.workmem)                                                                  AS workmem,
       stv_exec_state.num_parts,
       stv_exec_state.is_rrscan,
       stv_exec_state.is_delayed_scan
FROM stv_exec_state
         LEFT JOIN stv_proc_stat
                   ON stv_exec_state.query = stv_proc_stat.query AND stv_exec_state.segment = stv_proc_stat.segment AND
                      stv_exec_state.slice = stv_proc_stat.slice
GROUP BY stv_exec_state.userid, stv_exec_state.query, stv_exec_state.segment, stv_exec_state.step,
         stv_exec_state."label", stv_exec_state.is_diskbased, stv_exec_state.num_parts, stv_exec_state.is_rrscan,
         stv_exec_state.is_delayed_scan;

alter table svv_query_state
    owner to rdsdb;

