create view pg_stat_activity (datid, datname, procpid, usesysid, usename, current_query, query_start) as
SELECT d.oid                                           AS datid,
       d.datname,
       pg_stat_get_backend_pid(s.backendid)            AS procpid,
       pg_stat_get_backend_userid(s.backendid)         AS usesysid,
       u.usename,
       pg_stat_get_backend_activity(s.backendid)       AS current_query,
       pg_stat_get_backend_activity_start(s.backendid) AS query_start
FROM pg_database d,
     (SELECT pg_stat_get_backend_idset() AS backendid) s,
     pg_shadow u
WHERE pg_stat_get_backend_dbid(s.backendid) = d.oid
  AND pg_stat_get_backend_userid(s.backendid) = u.usesysid;

alter table pg_stat_activity
    owner to rdsdb;

