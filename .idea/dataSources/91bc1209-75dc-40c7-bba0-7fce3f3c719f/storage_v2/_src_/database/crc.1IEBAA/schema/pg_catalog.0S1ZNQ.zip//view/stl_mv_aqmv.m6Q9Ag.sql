create view stl_mv_aqmv
            (query, starttime, endtime, candidates, matches, aqmv_cost, original_cost, costing_time, aqmv_status) as
SELECT stll_mv_aqmv.query,
       stll_mv_aqmv.starttime,
       stll_mv_aqmv.endtime,
       stll_mv_aqmv.candidates,
       stll_mv_aqmv.matches,
       stll_mv_aqmv.aqmv_cost,
       stll_mv_aqmv.original_cost,
       stll_mv_aqmv.costing_time,
       stll_mv_aqmv.aqmv_status
FROM stll_mv_aqmv;

alter table stl_mv_aqmv
    owner to rdsdb;

