create view stl_unload_options
            (query, row_count, format, authentication, compression_type, encryption_type, manifest, maxfilesize,
             cross_region, opt_delimiter, opt_fixedwidth, opt_addquotes, opt_null_as, opt_escape, opt_allowoverwrite,
             opt_parallel, is_header, num_part_col, opt_incld_part_col, is_write_ext_tbl, is_encrypted_auto,
             opt_cleanpath)
as
SELECT stll_unload_options.query,
       stll_unload_options.row_count,
       stll_unload_options."format",
       stll_unload_options.authentication,
       stll_unload_options.compression_type,
       stll_unload_options.encryption_type,
       stll_unload_options."manifest",
       stll_unload_options."maxfilesize",
       stll_unload_options.cross_region,
       stll_unload_options.opt_delimiter,
       stll_unload_options.opt_fixedwidth,
       stll_unload_options.opt_addquotes,
       stll_unload_options.opt_null_as,
       stll_unload_options.opt_escape,
       stll_unload_options.opt_allowoverwrite,
       stll_unload_options.opt_parallel,
       stll_unload_options.is_header,
       stll_unload_options.num_part_col,
       stll_unload_options.opt_incld_part_col,
       stll_unload_options.is_write_ext_tbl,
       stll_unload_options.is_encrypted_auto,
       stll_unload_options.opt_cleanpath
FROM stll_unload_options;

alter table stl_unload_options
    owner to rdsdb;

