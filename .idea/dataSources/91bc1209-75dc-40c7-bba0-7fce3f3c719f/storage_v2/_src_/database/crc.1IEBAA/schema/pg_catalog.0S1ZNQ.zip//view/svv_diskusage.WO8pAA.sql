create view svv_diskusage
            (db_id, name, slice, col, tbl, blocknum, num_values, extended_limits, minvalue, maxvalue, sb_pos, pinned,
             on_disk, backed_up, modified, hdr_modified, unsorted, tombstone, preferred_diskno, temporary, newblock,
             num_readers, id, flags)
as
SELECT a.db_id,
       a.name,
       b.slice,
       b.col,
       b.tbl,
       b.blocknum,
       b.num_values,
       b.extended_limits,
       b."minvalue",
       b."maxvalue",
       b.sb_pos,
       b."pinned",
       b.on_disk,
       b.backed_up,
       b.modified,
       b.hdr_modified,
       b.unsorted,
       b.tombstone,
       b.preferred_diskno,
       b."temporary",
       b.newblock,
       b.num_readers,
       b.id,
       b.flags
FROM stv_tbl_perm a,
     stv_blocklist b
WHERE a.id = b.tbl
  AND a.slice = b.slice;

alter table svv_diskusage
    owner to rdsdb;

