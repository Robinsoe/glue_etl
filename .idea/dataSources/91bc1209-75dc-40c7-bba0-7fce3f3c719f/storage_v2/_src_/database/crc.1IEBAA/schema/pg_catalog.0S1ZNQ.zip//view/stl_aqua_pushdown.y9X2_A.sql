create view stl_aqua_pushdown
            (query, object_type, oid, argument_type, return_type, is_supported, reason_not_supported, xid) as
SELECT stll_aqua_pushdown.query,
       stll_aqua_pushdown.object_type,
       stll_aqua_pushdown.oid,
       stll_aqua_pushdown.argument_type,
       stll_aqua_pushdown.return_type,
       stll_aqua_pushdown.is_supported,
       stll_aqua_pushdown.reason_not_supported,
       stll_aqua_pushdown.xid
FROM stll_aqua_pushdown;

alter table stl_aqua_pushdown
    owner to rdsdb;

