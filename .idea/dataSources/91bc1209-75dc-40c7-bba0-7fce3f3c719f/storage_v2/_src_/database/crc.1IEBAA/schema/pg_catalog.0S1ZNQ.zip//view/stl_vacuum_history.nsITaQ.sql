create view stl_vacuum_history(table_id, eventtime, num_partitions, event, trigger, slice) as
SELECT stll_vacuum_history.table_id,
       stll_vacuum_history.eventtime,
       stll_vacuum_history.num_partitions,
       stll_vacuum_history.event,
       stll_vacuum_history."trigger",
       stll_vacuum_history.slice
FROM stll_vacuum_history;

alter table stl_vacuum_history
    owner to rdsdb;

