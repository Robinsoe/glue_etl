create view stl_snapshotbackup(snapshotname, xid, starttime, endtime, status) as
SELECT stll_snapshotbackup.snapshotname,
       stll_snapshotbackup.xid,
       stll_snapshotbackup.starttime,
       stll_snapshotbackup.endtime,
       stll_snapshotbackup.status
FROM stll_snapshotbackup;

alter table stl_snapshotbackup
    owner to rdsdb;

