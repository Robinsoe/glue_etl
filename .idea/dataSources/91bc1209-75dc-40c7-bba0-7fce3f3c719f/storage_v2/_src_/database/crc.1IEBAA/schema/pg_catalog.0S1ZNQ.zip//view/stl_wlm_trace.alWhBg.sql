create view stl_wlm_trace(userid, recordtime, pid, component, event, detail) as
SELECT stll_wlm_trace.userid,
       stll_wlm_trace.recordtime,
       stll_wlm_trace.pid,
       stll_wlm_trace.component,
       stll_wlm_trace.event,
       stll_wlm_trace.detail
FROM stll_wlm_trace;

alter table stl_wlm_trace
    owner to rdsdb;

