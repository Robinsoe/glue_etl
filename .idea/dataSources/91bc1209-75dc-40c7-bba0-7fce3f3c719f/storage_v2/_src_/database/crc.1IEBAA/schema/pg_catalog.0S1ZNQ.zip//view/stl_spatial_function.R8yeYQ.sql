create view stl_spatial_function(query, functionid, sqloperation) as
SELECT stll_spatial_function.query, stll_spatial_function.functionid, stll_spatial_function.sqloperation
FROM stll_spatial_function;

alter table stl_spatial_function
    owner to rdsdb;

