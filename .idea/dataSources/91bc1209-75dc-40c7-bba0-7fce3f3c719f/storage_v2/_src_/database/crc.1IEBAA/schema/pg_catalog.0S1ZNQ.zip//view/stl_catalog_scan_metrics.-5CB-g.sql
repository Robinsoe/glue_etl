create view stl_catalog_scan_metrics
            (xid, database, table_name, starttime, duration_msec, num_live_tups, num_dead_tups) as
SELECT stll_catalog_scan_metrics.xid,
       stll_catalog_scan_metrics."database",
       stll_catalog_scan_metrics.table_name,
       stll_catalog_scan_metrics.starttime,
       stll_catalog_scan_metrics.duration_msec,
       stll_catalog_scan_metrics.num_live_tups,
       stll_catalog_scan_metrics.num_dead_tups
FROM stll_catalog_scan_metrics;

alter table stl_catalog_scan_metrics
    owner to rdsdb;

