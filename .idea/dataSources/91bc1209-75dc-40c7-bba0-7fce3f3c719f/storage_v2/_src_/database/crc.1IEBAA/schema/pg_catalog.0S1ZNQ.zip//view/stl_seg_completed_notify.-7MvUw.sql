create view stl_seg_completed_notify(query, segment, node, slice, scheduled, completed) as
SELECT stll_seg_completed_notify.query,
       stll_seg_completed_notify.segment,
       stll_seg_completed_notify.node,
       stll_seg_completed_notify.slice,
       stll_seg_completed_notify.scheduled,
       stll_seg_completed_notify.completed
FROM stll_seg_completed_notify;

alter table stl_seg_completed_notify
    owner to rdsdb;

