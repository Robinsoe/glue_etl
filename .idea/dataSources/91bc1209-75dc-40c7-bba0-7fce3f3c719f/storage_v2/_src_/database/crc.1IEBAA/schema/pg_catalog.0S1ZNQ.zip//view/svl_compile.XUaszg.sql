create view svl_compile(userid, xid, pid, query, segment, locus, starttime, endtime, compile) as
SELECT stl_compile_info.userid,
       stl_compile_info.xid,
       stl_compile_info.pid,
       stl_compile_info.query,
       stl_compile_info.segment,
       stl_compile_info.locus,
       stl_compile_info.starttime,
       stl_compile_info.endtime,
       stl_compile_info.compile
FROM stl_compile_info;

alter table svl_compile
    owner to rdsdb;

