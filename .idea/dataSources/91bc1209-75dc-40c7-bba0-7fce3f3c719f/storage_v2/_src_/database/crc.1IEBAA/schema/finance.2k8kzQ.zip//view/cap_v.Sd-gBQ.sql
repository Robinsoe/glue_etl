create or replace view finance.cap_v
            (book_date, business_unit, creation_date, project_cd, company_cd, cost_center, element_cd, task_cd,
             task_template, acct_cd, clearing_no, line_no, line_desc, jva_bill_code, je_batch_name, task_name,
             default_cost_center, vendor_name, invoice_no, invoice_date, trans_source, desc_lines, vendor_no, job_no,
             attachment1, attachment2, attachment3, attachment4, cost_center_name, at_name, subat_name, orglev4_name,
             orglev5_name, element_lvl1_name, element_lvl2_name, element_lvl3_name, element_lvl4_name,
             element_lvl5_name, hyperion_acct_cd_short, hyperion_desc, project_name, template_name, acct_desc,
             task_lvl1_name, task_lvl2_name, task_lvl3_name, task_lvl4_name, reg_name, rep, service_date,
             serv_date_null, bpa_number, worktype, location, description, status, active_flag, max_name, amount)
as
SELECT a.book_date,
       bu.business_unit,
       a.creation_date,
       a.project_cd,
       a.company_cd,
       a.cost_center,
       a.element_cd,
       a.task_cd,
       a.task_template,
       a.acct_cd,
       a.clearing_no,
       a.line_no,
       a.line_desc,
       a.jva_bill_code,
       a.je_batch_name,
       a.task_name,
       a.default_cost_center,
       a.vendor_name,
       a.invoice_no,
       a.invoice_date,
       a.trans_source,
       a.desc_lines,
       a.vendor_no,
       a.job_no,
       a.attachment1,
       a.attachment2,
       a.attachment3,
       a.attachment4,
       b.cost_center_name,
       b.at_name,
       b.subat_name,
       b.orglev4_name,
       b.orglev5_name,
       c.element_lvl1_name,
       c.element_lvl2_name,
       c.element_lvl3_name,
       c.element_lvl4_name,
       c.element_lvl5_name,
       d.hyperion_acct_cd_short,
       d.hyperion_desc,
       e.project_name,
       e.template_name,
       f.acct_desc,
       g.task_lvl1_name,
       g.task_lvl2_name,
       g.task_lvl3_name,
       g.task_lvl4_name,
       b.reg_name,
       ft.rep,
       COALESCE(ft.service_date, a.book_date) AS service_date,
       CASE
           WHEN ft.service_date IS NULL THEN 'Y'::character varying
           ELSE 'N'::character varying
           END                                AS serv_date_null,
       ft.bpa_number,
       ma.worktype,
       ma."location",
       ma.description,
       ma.status,
       ma.active_flag,
       ma.max_name,
       sum(a.det_amount)                      AS amount
FROM finance.finods_oneoxy_trans_capex a
         LEFT JOIN finance.finods_cost_center_mv b ON a.cost_center = b.cost_center
         LEFT JOIN finance.crc_bu_org4_maapping bu
                   ON b.org_seqno::character varying::text = bu.org_seqno::character varying::text
         LEFT JOIN finance.finods_element_mv_tmp c ON a.element_cd::text = c.element_cd::text
         LEFT JOIN finance.finods_hyperion_account d ON a.hyperion_acct_cd::text = d.hyperion_acct_cd::text
         LEFT JOIN finance.finods_proj e ON a.project_cd::text = e.project_cd::text
         LEFT JOIN finance.finods_account f ON a.acct_cd::text = f.acct_cd::text
         LEFT JOIN finance.finods_tasks_mv g
                   ON a.task_cd::text = g.task_number::text AND a.task_template::text = g.task_template::text
         LEFT JOIN finance.invoices ft
                   ON a.vendor_no::character varying::text = ft.vendor_no::text AND a.invoice_no::text = ft.invoice_no::text
         LEFT JOIN finance.maximo_workorder_v ma ON ma.wonum::text = a.job_no::text
GROUP BY a.book_date, bu.business_unit, a.creation_date, a.project_cd, a.company_cd, a.cost_center, a.element_cd,
         a.task_cd, a.task_template, a.acct_cd, a.clearing_no, a.line_no, a.line_desc, a.jva_bill_code, a.je_batch_name,
         a.task_name, a.default_cost_center, a.vendor_name, a.invoice_no, a.invoice_date, a.trans_source, a.desc_lines,
         a.vendor_no, a.job_no, a.attachment1, a.attachment2, a.attachment3, a.attachment4, b.cost_center_name,
         b.at_name, b.subat_name, b.orglev4_name, b.orglev5_name, c.element_lvl1_name, c.element_lvl2_name,
         c.element_lvl3_name, c.element_lvl4_name, c.element_lvl5_name, d.hyperion_acct_cd_short, d.hyperion_desc,
         e.project_name, e.template_name, f.acct_desc, g.task_lvl1_name, g.task_lvl2_name, g.task_lvl3_name,
         g.task_lvl4_name, b.reg_name, ft.rep, ft.service_date,
         CASE
             WHEN ft.service_date IS NULL THEN 'Y'::character varying
             ELSE 'N'::character varying
             END, ft.bpa_number, ma.worktype, ma."location", ma.description, ma.status, ma.active_flag, ma.max_name
with no schema binding;

alter table cap_v
    owner to juan;

grant select on cap_v to david;

