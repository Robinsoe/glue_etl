create view stl_network_throttle
            (log_time, client_id, registered, throttle_step, max_concurrent_sessions, num_high_throttle_set,
             num_low_throttle_set, num_low_unthrottle_set, num_zero_unthrottle_set, avg_token_wait_time,
             min_token_wait_time, max_token_wait_time, times_thread_wait_for_token, avg_token_hold_time,
             min_token_hold_time, max_token_hold_time, times_thread_held_token)
as
SELECT stll_network_throttle.log_time,
       stll_network_throttle.client_id,
       stll_network_throttle.registered,
       stll_network_throttle.throttle_step,
       stll_network_throttle.max_concurrent_sessions,
       stll_network_throttle.num_high_throttle_set,
       stll_network_throttle.num_low_throttle_set,
       stll_network_throttle.num_low_unthrottle_set,
       stll_network_throttle.num_zero_unthrottle_set,
       stll_network_throttle.avg_token_wait_time,
       stll_network_throttle.min_token_wait_time,
       stll_network_throttle.max_token_wait_time,
       stll_network_throttle.times_thread_wait_for_token,
       stll_network_throttle.avg_token_hold_time,
       stll_network_throttle.min_token_hold_time,
       stll_network_throttle.max_token_hold_time,
       stll_network_throttle.times_thread_held_token
FROM stll_network_throttle;

alter table stl_network_throttle
    owner to rdsdb;

