create view stl_compile_service
            (userid, xid, pid, query, segment, locus, bytes, path, lookupstarttime, lookupendtime, lookupsuccess,
             putstarttime, putendtime, putsuccess)
as
SELECT stll_compile_service.userid,
       stll_compile_service.xid,
       stll_compile_service.pid,
       stll_compile_service.query,
       stll_compile_service.segment,
       stll_compile_service.locus,
       stll_compile_service.bytes,
       stll_compile_service."path",
       stll_compile_service.lookupstarttime,
       stll_compile_service.lookupendtime,
       stll_compile_service.lookupsuccess,
       stll_compile_service.putstarttime,
       stll_compile_service.putendtime,
       stll_compile_service.putsuccess
FROM stll_compile_service;

alter table stl_compile_service
    owner to rdsdb;

