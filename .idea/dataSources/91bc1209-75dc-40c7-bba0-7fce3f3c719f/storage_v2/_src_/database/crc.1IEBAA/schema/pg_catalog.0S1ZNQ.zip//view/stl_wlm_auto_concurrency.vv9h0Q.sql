create view stl_wlm_auto_concurrency
            (now, heavy_slots, light_slots, heavy_util, light_util, utilization_state, new_light_slots, window_time_sec,
             heavy_queries_finished, heavy_queries_exec_time, heavy_queries_queue_time_sec, light_queries_finished,
             light_queries_exec_time_sec, light_queries_queue_time_sec, spilling_queries, spilled_blocks,
             light_queries_queued, heavy_queries_queued, avg_exec_time_heavy_sec, p90_exec_time_heavy_sec)
as
SELECT stll_wlm_auto_concurrency.now,
       stll_wlm_auto_concurrency.heavy_slots,
       stll_wlm_auto_concurrency.light_slots,
       stll_wlm_auto_concurrency.heavy_util,
       stll_wlm_auto_concurrency.light_util,
       stll_wlm_auto_concurrency.utilization_state,
       stll_wlm_auto_concurrency.new_light_slots,
       stll_wlm_auto_concurrency.window_time_sec,
       stll_wlm_auto_concurrency.heavy_queries_finished,
       stll_wlm_auto_concurrency.heavy_queries_exec_time,
       stll_wlm_auto_concurrency.heavy_queries_queue_time_sec,
       stll_wlm_auto_concurrency.light_queries_finished,
       stll_wlm_auto_concurrency.light_queries_exec_time_sec,
       stll_wlm_auto_concurrency.light_queries_queue_time_sec,
       stll_wlm_auto_concurrency.spilling_queries,
       stll_wlm_auto_concurrency.spilled_blocks,
       stll_wlm_auto_concurrency.light_queries_queued,
       stll_wlm_auto_concurrency.heavy_queries_queued,
       stll_wlm_auto_concurrency.avg_exec_time_heavy_sec,
       stll_wlm_auto_concurrency.p90_exec_time_heavy_sec
FROM stll_wlm_auto_concurrency;

alter table stl_wlm_auto_concurrency
    owner to rdsdb;

