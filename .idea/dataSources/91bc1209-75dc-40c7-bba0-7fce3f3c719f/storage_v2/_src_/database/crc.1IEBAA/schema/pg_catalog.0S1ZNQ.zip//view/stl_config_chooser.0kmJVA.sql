create view stl_config_chooser(name, value) as
SELECT stll_config_chooser.name, stll_config_chooser.value
FROM stll_config_chooser;

alter table stl_config_chooser
    owner to rdsdb;

