create view stl_aggr
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, slots, occupied, maxlength,
             tbl, is_diskbased, workmem, type, resizes, flushable, varchar_agg_opt, varagg_opt_bitmap,
             used_agg_prefetching)
as
SELECT stll_aggr.userid,
       stll_aggr.query,
       stll_aggr.slice,
       stll_aggr.segment,
       stll_aggr.step,
       stll_aggr.starttime,
       stll_aggr.endtime,
       stll_aggr.tasknum,
       stll_aggr."rows",
       stll_aggr.bytes,
       stll_aggr.slots,
       stll_aggr.occupied,
       stll_aggr.maxlength,
       stll_aggr.tbl,
       stll_aggr.is_diskbased,
       stll_aggr.workmem,
       stll_aggr."type",
       stll_aggr.resizes,
       stll_aggr.flushable,
       stll_aggr.varchar_agg_opt,
       stll_aggr.varagg_opt_bitmap,
       stll_aggr.used_agg_prefetching
FROM stll_aggr;

alter table stl_aggr
    owner to rdsdb;

