create view stl_s3pushdown (query, object_type, oid, argument_type, return_type, is_supported, external_source, xid) as
SELECT stll_s3pushdown.query,
       stll_s3pushdown.object_type,
       stll_s3pushdown.oid,
       stll_s3pushdown.argument_type,
       stll_s3pushdown.return_type,
       stll_s3pushdown.is_supported,
       stll_s3pushdown.external_source,
       stll_s3pushdown.xid
FROM stll_s3pushdown;

alter table stl_s3pushdown
    owner to rdsdb;

