create view stl_rehydration_metrics
            (start_time, end_time, rehydrated_blocks, primary_reads, primary_read_latency, mirror_reads,
             mirror_read_latency, s3_reads, s3_read_latency, primary_writes, primary_write_latency, mirror_writes,
             mirror_write_latency, in_progress, node, avg_rerep_reqs, s3_writes, s3_write_latency)
as
SELECT stll_rehydration_metrics.start_time,
       stll_rehydration_metrics.end_time,
       stll_rehydration_metrics.rehydrated_blocks,
       stll_rehydration_metrics.primary_reads,
       stll_rehydration_metrics.primary_read_latency,
       stll_rehydration_metrics.mirror_reads,
       stll_rehydration_metrics.mirror_read_latency,
       stll_rehydration_metrics.s3_reads,
       stll_rehydration_metrics.s3_read_latency,
       stll_rehydration_metrics.primary_writes,
       stll_rehydration_metrics.primary_write_latency,
       stll_rehydration_metrics.mirror_writes,
       stll_rehydration_metrics.mirror_write_latency,
       stll_rehydration_metrics.in_progress,
       stll_rehydration_metrics.node,
       stll_rehydration_metrics.avg_rerep_reqs,
       stll_rehydration_metrics.s3_writes,
       stll_rehydration_metrics.s3_write_latency
FROM stll_rehydration_metrics;

alter table stl_rehydration_metrics
    owner to rdsdb;

