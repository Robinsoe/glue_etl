create view stl_aqua_requests
            (query, uuid, pid, segment, node, slice, aqua_shard_id, eventtime, duration, aqua_table_arn, aqua_endpoint,
             failed, request_id)
as
SELECT stll_aqua_requests.query,
       stll_aqua_requests.uuid,
       stll_aqua_requests.pid,
       stll_aqua_requests.segment,
       stll_aqua_requests.node,
       stll_aqua_requests.slice,
       stll_aqua_requests.aqua_shard_id,
       stll_aqua_requests.eventtime,
       stll_aqua_requests.duration,
       stll_aqua_requests.aqua_table_arn,
       stll_aqua_requests.aqua_endpoint,
       stll_aqua_requests.failed,
       stll_aqua_requests.request_id
FROM stll_aqua_requests;

alter table stl_aqua_requests
    owner to rdsdb;

