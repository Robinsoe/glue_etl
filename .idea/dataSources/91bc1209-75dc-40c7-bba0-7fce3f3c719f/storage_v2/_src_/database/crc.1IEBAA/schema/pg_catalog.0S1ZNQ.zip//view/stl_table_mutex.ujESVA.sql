create view stl_table_mutex (query, segment, step, slice, pid, eventtime, table_id, data_slice, mode, type) as
SELECT stll_table_mutex.query,
       stll_table_mutex.segment,
       stll_table_mutex.step,
       stll_table_mutex.slice,
       stll_table_mutex.pid,
       stll_table_mutex.eventtime,
       stll_table_mutex.table_id,
       stll_table_mutex.data_slice,
       stll_table_mutex."mode",
       stll_table_mutex."type"
FROM stll_table_mutex;

alter table stl_table_mutex
    owner to rdsdb;

