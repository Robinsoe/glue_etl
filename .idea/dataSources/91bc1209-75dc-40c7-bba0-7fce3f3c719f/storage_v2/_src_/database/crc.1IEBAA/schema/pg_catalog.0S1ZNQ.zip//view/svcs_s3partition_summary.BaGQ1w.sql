create view svcs_s3partition_summary
            (query, segment, assignment, min_starttime, max_endtime, min_duration, max_duration, avg_duration,
             total_partitions, qualified_partitions, min_assigned_partitions, max_assigned_partitions,
             avg_assigned_partitions)
as
SELECT svcs_s3partition_elimination.query,
       svcs_s3partition_elimination.segment,
       svcs_s3partition_elimination."assignment",
       min(svcs_s3partition_elimination.starttime) AS              min_starttime,
       "max"(svcs_s3partition_elimination.endtime) AS              max_endtime,
       min(date_diff('us'::text, svcs_s3partition_elimination.starttime,
                     svcs_s3partition_elimination.endtime)) AS     min_duration,
       "max"(date_diff('us'::text, svcs_s3partition_elimination.starttime,
                       svcs_s3partition_elimination.endtime)) AS   max_duration,
       avg(date_diff('us'::text, svcs_s3partition_elimination.starttime,
                     svcs_s3partition_elimination.endtime)) AS     avg_duration,
       "max"(svcs_s3partition_elimination.total_partitions) AS     total_partitions,
       "max"(svcs_s3partition_elimination.qualified_partitions) AS qualified_partitions,
       min(svcs_s3partition_elimination.assigned_partitions) AS    min_assigned_partitions,
       "max"(svcs_s3partition_elimination.assigned_partitions) AS  max_assigned_partitions,
       avg(svcs_s3partition_elimination.assigned_partitions) AS    avg_assigned_partitions
FROM svcs_s3partition_elimination
WHERE svcs_s3partition_elimination.scan_type = 2
  AND ((EXISTS(SELECT 1
               FROM pg_user
               WHERE pg_user.usename = "current_user"()::name
                 AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                          FROM pg_shadow_extended
                                                          WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                            AND pg_shadow_extended.colnum = 2
                                                            AND pg_shadow_extended.value = -1::text)) OR
       svcs_s3partition_elimination.userid = "current_user_id"())
GROUP BY svcs_s3partition_elimination.query, svcs_s3partition_elimination.segment,
         svcs_s3partition_elimination."assignment"
UNION ALL
SELECT svl_s3partition_summary.query,
       svl_s3partition_summary.segment,
       svl_s3partition_summary."assignment",
       svl_s3partition_summary.min_starttime,
       svl_s3partition_summary.max_endtime,
       svl_s3partition_summary.min_duration,
       svl_s3partition_summary.max_duration,
       svl_s3partition_summary.avg_duration,
       svl_s3partition_summary.total_partitions,
       svl_s3partition_summary.qualified_partitions,
       svl_s3partition_summary.min_assigned_partitions,
       svl_s3partition_summary.max_assigned_partitions,
       svl_s3partition_summary.avg_assigned_partitions
FROM svl_s3partition_summary;

alter table svcs_s3partition_summary
    owner to rdsdb;

