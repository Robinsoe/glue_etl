create view stl_prefetch_stats(eventtime, node, pid, query, tableid, columnid, numprefetches) as
SELECT stll_prefetch_stats.eventtime,
       stll_prefetch_stats.node,
       stll_prefetch_stats.pid,
       stll_prefetch_stats.query,
       stll_prefetch_stats.tableid,
       stll_prefetch_stats.columnid,
       stll_prefetch_stats.numprefetches
FROM stll_prefetch_stats;

alter table stl_prefetch_stats
    owner to rdsdb;

