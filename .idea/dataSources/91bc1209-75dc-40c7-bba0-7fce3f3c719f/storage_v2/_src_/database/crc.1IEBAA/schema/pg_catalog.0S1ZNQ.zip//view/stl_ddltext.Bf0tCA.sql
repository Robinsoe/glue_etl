create view stl_ddltext(userid, xid, pid, label, starttime, endtime, sequence, text) as
SELECT stll_ddltext.userid,
       stll_ddltext.xid,
       stll_ddltext.pid,
       stll_ddltext."label",
       stll_ddltext.starttime,
       stll_ddltext.endtime,
       stll_ddltext."sequence",
       stll_ddltext.text
FROM stll_ddltext;

alter table stl_ddltext
    owner to rdsdb;

