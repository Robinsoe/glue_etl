create view stl_version(bootstrap_time, db_version, restart_reason) as
SELECT stll_version.bootstrap_time, stll_version.db_version, stll_version.restart_reason
FROM stll_version;

alter table stl_version
    owner to rdsdb;

