create view stl_nestloop
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, tbl, checksum, distribution) as
SELECT stll_nestloop.userid,
       stll_nestloop.query,
       stll_nestloop.slice,
       stll_nestloop.segment,
       stll_nestloop.step,
       stll_nestloop.starttime,
       stll_nestloop.endtime,
       stll_nestloop.tasknum,
       stll_nestloop."rows",
       stll_nestloop.tbl,
       stll_nestloop.checksum,
       stll_nestloop.distribution
FROM stll_nestloop;

alter table stl_nestloop
    owner to rdsdb;

