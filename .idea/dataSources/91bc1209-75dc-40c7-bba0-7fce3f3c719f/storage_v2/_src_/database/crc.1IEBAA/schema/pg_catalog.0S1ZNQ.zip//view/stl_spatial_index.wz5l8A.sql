create view stl_spatial_index
            (query, slice, segment, step, type, num_inner, num_outer, pruned_tuples, predicate, created, mem_allowance,
             predicted_size)
as
SELECT stll_spatial_index.query,
       stll_spatial_index.slice,
       stll_spatial_index.segment,
       stll_spatial_index.step,
       stll_spatial_index."type",
       stll_spatial_index.num_inner,
       stll_spatial_index.num_outer,
       stll_spatial_index.pruned_tuples,
       stll_spatial_index."predicate",
       stll_spatial_index.created,
       stll_spatial_index.mem_allowance,
       stll_spatial_index.predicted_size
FROM stll_spatial_index;

alter table stl_spatial_index
    owner to rdsdb;

