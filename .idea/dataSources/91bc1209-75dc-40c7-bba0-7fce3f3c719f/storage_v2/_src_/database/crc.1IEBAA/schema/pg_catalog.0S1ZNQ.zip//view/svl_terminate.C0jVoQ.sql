create view svl_terminate(pid, eventtime, userid, type) as
SELECT stl_terminate.pid,
       stl_terminate.eventtime,
       stl_terminate.userid,
       CASE
           WHEN stl_terminate.signal = 2 THEN 'CANCEL'::text
           WHEN stl_terminate.signal = 15 THEN 'TERMINATE'::text
           ELSE 'UNKNOWN'::text
           END AS "type"
FROM stl_terminate;

alter table svl_terminate
    owner to rdsdb;

