create view stl_query_heap_memory_usage
            (recordtime, pid, xid, userid, checkpoint, heap_mem_usage, heap_max_mem_usage) as
SELECT stll_query_heap_memory_usage.recordtime,
       stll_query_heap_memory_usage.pid,
       stll_query_heap_memory_usage.xid,
       stll_query_heap_memory_usage.userid,
       stll_query_heap_memory_usage.checkpoint,
       stll_query_heap_memory_usage.heap_mem_usage,
       stll_query_heap_memory_usage.heap_max_mem_usage
FROM stll_query_heap_memory_usage;

alter table stl_query_heap_memory_usage
    owner to rdsdb;

