create view stl_dag_cleanup
            (ending_xid, is_commit, timestamp, event, dag_verts, txn_set_size, lowest_added_xid, highest_added_xid) as
SELECT stll_dag_cleanup.ending_xid,
       stll_dag_cleanup.is_commit,
       stll_dag_cleanup."timestamp",
       stll_dag_cleanup.event,
       stll_dag_cleanup.dag_verts,
       stll_dag_cleanup.txn_set_size,
       stll_dag_cleanup.lowest_added_xid,
       stll_dag_cleanup.highest_added_xid
FROM stll_dag_cleanup;

alter table stl_dag_cleanup
    owner to rdsdb;

