create view stl_omnisql_rewrite_rules(query, rule, count, time, type, module) as
SELECT stll_omnisql_rewrite_rules.query,
       stll_omnisql_rewrite_rules."rule",
       stll_omnisql_rewrite_rules.count,
       stll_omnisql_rewrite_rules."time",
       stll_omnisql_rewrite_rules."type",
       stll_omnisql_rewrite_rules.module
FROM stll_omnisql_rewrite_rules;

alter table stl_omnisql_rewrite_rules
    owner to rdsdb;

