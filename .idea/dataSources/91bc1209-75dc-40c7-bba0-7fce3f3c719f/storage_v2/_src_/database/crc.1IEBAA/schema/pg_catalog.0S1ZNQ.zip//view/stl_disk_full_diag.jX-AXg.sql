create view stl_disk_full_diag(currenttime, node_num, query_id, temp_blocks) as
SELECT stll_disk_full_diag.currenttime,
       stll_disk_full_diag.node_num,
       stll_disk_full_diag.query_id,
       stll_disk_full_diag.temp_blocks
FROM stll_disk_full_diag;

alter table stl_disk_full_diag
    owner to rdsdb;

