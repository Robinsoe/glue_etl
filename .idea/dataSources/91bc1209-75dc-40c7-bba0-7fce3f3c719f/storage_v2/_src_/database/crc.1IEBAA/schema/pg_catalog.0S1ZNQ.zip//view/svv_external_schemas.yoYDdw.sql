create view svv_external_schemas(esoid, eskind, schemaname, esowner, databasename, esoptions) as
SELECT b.esoid, b.eskind, a.nspname AS schemaname, a.nspowner AS esowner, b.esdbname AS databasename, b.esoptions
FROM pg_namespace a,
     pg_external_schema b
WHERE a.oid = b.esoid;

alter table svv_external_schemas
    owner to rdsdb;

