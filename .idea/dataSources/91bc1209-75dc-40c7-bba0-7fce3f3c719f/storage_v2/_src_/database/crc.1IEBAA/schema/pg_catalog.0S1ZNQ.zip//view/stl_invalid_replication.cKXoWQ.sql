create view stl_invalid_replication (recordtime, slice, sb_pos, node0, diskno0, node1, diskno1, node2, diskno2) as
SELECT stll_invalid_replication.recordtime,
       stll_invalid_replication.slice,
       stll_invalid_replication.sb_pos,
       stll_invalid_replication.node0,
       stll_invalid_replication.diskno0,
       stll_invalid_replication.node1,
       stll_invalid_replication.diskno1,
       stll_invalid_replication.node2,
       stll_invalid_replication.diskno2
FROM stll_invalid_replication;

alter table stl_invalid_replication
    owner to rdsdb;

