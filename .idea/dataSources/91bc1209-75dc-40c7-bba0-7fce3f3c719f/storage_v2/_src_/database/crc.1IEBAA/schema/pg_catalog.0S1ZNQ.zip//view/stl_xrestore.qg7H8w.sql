create view stl_xrestore
            (backup_id, node, catalog_download_start_time, catalog_download_end_time, slice_transfer_start_time,
             slice_transfer_end_time)
as
SELECT stll_xrestore.backup_id,
       stll_xrestore.node,
       stll_xrestore.catalog_download_start_time,
       stll_xrestore.catalog_download_end_time,
       stll_xrestore.slice_transfer_start_time,
       stll_xrestore.slice_transfer_end_time
FROM stll_xrestore;

alter table stl_xrestore
    owner to rdsdb;

