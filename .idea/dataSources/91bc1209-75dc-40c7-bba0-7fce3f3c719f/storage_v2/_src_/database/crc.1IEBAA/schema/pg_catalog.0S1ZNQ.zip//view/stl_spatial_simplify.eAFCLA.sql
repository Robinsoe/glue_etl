create view stl_spatial_simplify
            (userid, query, line_number, maximum_tolerance, maximum_size, initial_size, simplified, final_size,
             final_tolerance, num_iterations)
as
SELECT stll_spatial_simplify.userid,
       stll_spatial_simplify.query,
       stll_spatial_simplify.line_number,
       stll_spatial_simplify.maximum_tolerance,
       stll_spatial_simplify.maximum_size,
       stll_spatial_simplify.initial_size,
       stll_spatial_simplify.simplified,
       stll_spatial_simplify.final_size,
       stll_spatial_simplify.final_tolerance,
       stll_spatial_simplify.num_iterations
FROM stll_spatial_simplify;

alter table stl_spatial_simplify
    owner to rdsdb;

