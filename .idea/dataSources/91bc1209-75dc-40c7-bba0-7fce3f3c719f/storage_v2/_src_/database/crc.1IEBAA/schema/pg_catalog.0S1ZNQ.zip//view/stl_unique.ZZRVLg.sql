create view stl_unique
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, type, is_diskbased, slots, workmem,
             max_buffers_used, resizes, occupied, flushable, used_unique_prefetching)
as
SELECT stll_unique.userid,
       stll_unique.query,
       stll_unique.slice,
       stll_unique.segment,
       stll_unique.step,
       stll_unique.starttime,
       stll_unique.endtime,
       stll_unique.tasknum,
       stll_unique."rows",
       stll_unique."type",
       stll_unique.is_diskbased,
       stll_unique.slots,
       stll_unique.workmem,
       stll_unique.max_buffers_used,
       stll_unique.resizes,
       stll_unique.occupied,
       stll_unique.flushable,
       stll_unique.used_unique_prefetching
FROM stll_unique;

alter table stl_unique
    owner to rdsdb;

