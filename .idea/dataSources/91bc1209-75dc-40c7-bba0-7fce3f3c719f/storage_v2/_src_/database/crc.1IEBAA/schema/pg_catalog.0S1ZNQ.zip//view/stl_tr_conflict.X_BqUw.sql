create view stl_tr_conflict(xact_id, process_id, xact_start_ts, abort_time, table_id) as
SELECT stll_tr_conflict.xact_id,
       stll_tr_conflict.process_id,
       stll_tr_conflict.xact_start_ts,
       stll_tr_conflict.abort_time,
       stll_tr_conflict.table_id
FROM stll_tr_conflict;

alter table stl_tr_conflict
    owner to rdsdb;

