create view stl_commit_checkpoint
            (xid, start_acquire_checkpoint_lock, start_acquire_checkpoint_start_lock, start_checkpoint_work,
             start_create_control_file, end_create_control_file, end_checkpoint)
as
SELECT stll_commit_checkpoint.xid,
       stll_commit_checkpoint.start_acquire_checkpoint_lock,
       stll_commit_checkpoint.start_acquire_checkpoint_start_lock,
       stll_commit_checkpoint.start_checkpoint_work,
       stll_commit_checkpoint.start_create_control_file,
       stll_commit_checkpoint.end_create_control_file,
       stll_commit_checkpoint.end_checkpoint
FROM stll_commit_checkpoint;

alter table stl_commit_checkpoint
    owner to rdsdb;

