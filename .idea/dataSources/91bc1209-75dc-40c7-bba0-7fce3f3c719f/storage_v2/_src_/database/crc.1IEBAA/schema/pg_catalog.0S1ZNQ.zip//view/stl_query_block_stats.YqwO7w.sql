create view stl_query_block_stats
            (query, slice, segment, block_reads, block_faults, total_block_fetchtime, max_block_fetchtime,
             transblock_reads, transblock_faults, total_transblock_fetchtime, max_transblock_fetchtime, blocks_used,
             block_reads_already_in_s3, disk_fetches, disk_prefetches, s3_fetches, s3_prefetches, trans_block_fetches,
             trans_block_prefetches)
as
SELECT stll_query_block_stats.query,
       stll_query_block_stats.slice,
       stll_query_block_stats.segment,
       stll_query_block_stats.block_reads,
       stll_query_block_stats.block_faults,
       stll_query_block_stats.total_block_fetchtime,
       stll_query_block_stats.max_block_fetchtime,
       stll_query_block_stats.transblock_reads,
       stll_query_block_stats.transblock_faults,
       stll_query_block_stats.total_transblock_fetchtime,
       stll_query_block_stats.max_transblock_fetchtime,
       stll_query_block_stats.blocks_used,
       stll_query_block_stats.block_reads_already_in_s3,
       stll_query_block_stats.disk_fetches,
       stll_query_block_stats.disk_prefetches,
       stll_query_block_stats.s3_fetches,
       stll_query_block_stats.s3_prefetches,
       stll_query_block_stats.trans_block_fetches,
       stll_query_block_stats.trans_block_prefetches
FROM stll_query_block_stats;

alter table stl_query_block_stats
    owner to rdsdb;

