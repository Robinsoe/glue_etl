create view monthly_fv
            (operatorname, fieldname, api10, latitude, longitude, reportdate, gas_airinjected_mcf,
             steam_waterinjected_bbl, oilorcondensateproduced, gasproduced_mcf, waterproduced_bbl, legal_well_name,
             leasename)
as
SELECT w.operatorname,
       w.fieldname,
       w.api10,
       w.latitude,
       w.longitude,
       u.reportdate,
       u.gas_airinjected_mcf,
       u.steam_waterinjected_bbl,
       u.oilorcondensateproduced,
       u.gasproduced_mcf,
       u.waterproduced_bbl,
       w.legal_well_name,
       w.leasename
FROM calgem.allwells_v w
         JOIN calgem.u_inj_prod u ON w.api10::text = u.api10::text;

alter table monthly_fv
    owner to crc;

