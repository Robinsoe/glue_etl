create view stl_net_stat
            (currenttime, sampletime, query, segment, node, iface, rxbytes, rxpackets, rxerrors, rxdrops, rxfifo,
             rxframe, rxcompressed, rxmulticast, txbytes, txpackets, txerrors, txdrops, txfifo, txcollisions, txcarrier,
             txcompressed)
as
SELECT stll_net_stat.currenttime,
       stll_net_stat.sampletime,
       stll_net_stat.query,
       stll_net_stat.segment,
       stll_net_stat.node,
       stll_net_stat.iface,
       stll_net_stat.rxbytes,
       stll_net_stat.rxpackets,
       stll_net_stat.rxerrors,
       stll_net_stat.rxdrops,
       stll_net_stat.rxfifo,
       stll_net_stat.rxframe,
       stll_net_stat.rxcompressed,
       stll_net_stat.rxmulticast,
       stll_net_stat.txbytes,
       stll_net_stat.txpackets,
       stll_net_stat.txerrors,
       stll_net_stat.txdrops,
       stll_net_stat.txfifo,
       stll_net_stat.txcollisions,
       stll_net_stat.txcarrier,
       stll_net_stat.txcompressed
FROM stll_net_stat;

alter table stl_net_stat
    owner to rdsdb;

