create view svl_query_metrics_summary
            (userid, query, service_class, query_cpu_time, query_blocks_read, query_execution_time,
             query_cpu_usage_percent, query_temp_blocks_to_disk, segment_execution_time, cpu_skew, io_skew,
             scan_row_count, join_row_count, nested_loop_join_row_count, return_row_count, spectrum_scan_row_count,
             spectrum_scan_size_mb, query_queue_time, service_class_name)
as
SELECT svl_query_metrics.userid,
       svl_query_metrics.query,
       svl_query_metrics.service_class,
       "max"(svl_query_metrics.query_cpu_time)             AS query_cpu_time,
       "max"(svl_query_metrics.query_blocks_read)          AS query_blocks_read,
       "max"(svl_query_metrics.query_execution_time)       AS query_execution_time,
       "max"(svl_query_metrics.query_cpu_usage_percent)    AS query_cpu_usage_percent,
       "max"(svl_query_metrics.query_temp_blocks_to_disk)  AS query_temp_blocks_to_disk,
       "max"(svl_query_metrics.segment_execution_time)     AS segment_execution_time,
       "max"(svl_query_metrics.cpu_skew)                   AS cpu_skew,
       "max"(svl_query_metrics.io_skew)                    AS io_skew,
       "max"(svl_query_metrics.scan_row_count)             AS scan_row_count,
       "max"(svl_query_metrics.join_row_count)             AS join_row_count,
       "max"(svl_query_metrics.nested_loop_join_row_count) AS nested_loop_join_row_count,
       "max"(svl_query_metrics.return_row_count)           AS return_row_count,
       "max"(svl_query_metrics.spectrum_scan_row_count)    AS spectrum_scan_row_count,
       "max"(svl_query_metrics.spectrum_scan_size_mb)      AS spectrum_scan_size_mb,
       "max"(svl_query_metrics.query_queue_time)           AS query_queue_time,
       svl_query_metrics.service_class_name
FROM svl_query_metrics
GROUP BY svl_query_metrics.userid, svl_query_metrics.query, svl_query_metrics.service_class,
         svl_query_metrics.service_class_name;

alter table svl_query_metrics_summary
    owner to rdsdb;

