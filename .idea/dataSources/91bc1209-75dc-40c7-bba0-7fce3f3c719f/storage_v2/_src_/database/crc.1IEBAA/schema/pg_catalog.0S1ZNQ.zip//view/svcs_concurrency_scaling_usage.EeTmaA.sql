create view svcs_concurrency_scaling_usage(start_time, end_time, queries, usage_in_seconds) as
SELECT f.starttime                                                             AS start_time,
       f.endtime                                                               AS end_time,
       count(DISTINCT qcnt.query)                                              AS queries,
       ceil(date_diff('ms'::text, f.starttime, f.endtime)::numeric / 1000.000) AS usage_in_seconds
FROM (SELECT s."cluster", s.starttime, min(e.endtime) AS endtime
      FROM (SELECT start1."cluster", start1.query, start1.starttime, start1.endtime
            FROM (SELECT stl_concurrency_scaling_usage."cluster",
                         stl_concurrency_scaling_usage.query,
                         stl_concurrency_scaling_usage.starttime,
                         stl_concurrency_scaling_usage.endtime
                  FROM stl_concurrency_scaling_usage) start1
                     LEFT JOIN (SELECT stl_concurrency_scaling_usage."cluster",
                                       stl_concurrency_scaling_usage.query,
                                       stl_concurrency_scaling_usage.starttime,
                                       stl_concurrency_scaling_usage.endtime
                                FROM stl_concurrency_scaling_usage) start2
                               ON start1."cluster" = start2."cluster" AND start1.starttime > start2.starttime AND
                                  start1.starttime <= start2.endtime
            WHERE start2."cluster" IS NULL) s
               JOIN (SELECT end1."cluster", end1.query, end1.starttime, end1.endtime
                     FROM (SELECT stl_concurrency_scaling_usage."cluster",
                                  stl_concurrency_scaling_usage.query,
                                  stl_concurrency_scaling_usage.starttime,
                                  stl_concurrency_scaling_usage.endtime
                           FROM stl_concurrency_scaling_usage) end1
                              LEFT JOIN (SELECT stl_concurrency_scaling_usage."cluster",
                                                stl_concurrency_scaling_usage.query,
                                                stl_concurrency_scaling_usage.starttime,
                                                stl_concurrency_scaling_usage.endtime
                                         FROM stl_concurrency_scaling_usage) end2
                                        ON end1."cluster" = end2."cluster" AND end1.endtime >= end2.starttime AND
                                           end1.endtime < end2.endtime
                     WHERE end2."cluster" IS NULL) e ON s."cluster" = e."cluster" AND s.starttime <= e.endtime
      GROUP BY s."cluster", s.starttime) f
         JOIN (SELECT stl_concurrency_scaling_usage."cluster",
                      stl_concurrency_scaling_usage.query,
                      stl_concurrency_scaling_usage.starttime,
                      stl_concurrency_scaling_usage.endtime
               FROM stl_concurrency_scaling_usage) qcnt
              ON f."cluster" = qcnt."cluster" AND f.starttime <= qcnt.starttime AND f.endtime >= qcnt.endtime AND
                 qcnt.query > 0
GROUP BY f."cluster", f.starttime, f.endtime
ORDER BY f.starttime;

alter table svcs_concurrency_scaling_usage
    owner to rdsdb;

