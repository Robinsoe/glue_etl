create view stl_datashare_request_consumer
            (userid, xid, pid, initial_query_time, requestid, sb_version, dbtype, dbid, api_call, starttime, endtime,
             status, message)
as
SELECT stll_datashare_request_consumer.userid,
       stll_datashare_request_consumer.xid,
       stll_datashare_request_consumer.pid,
       stll_datashare_request_consumer.initial_query_time,
       stll_datashare_request_consumer.requestid,
       stll_datashare_request_consumer.sb_version,
       stll_datashare_request_consumer.dbtype,
       stll_datashare_request_consumer.dbid,
       stll_datashare_request_consumer.api_call,
       stll_datashare_request_consumer.starttime,
       stll_datashare_request_consumer.endtime,
       stll_datashare_request_consumer.status,
       stll_datashare_request_consumer.message
FROM stll_datashare_request_consumer;

alter table stl_datashare_request_consumer
    owner to rdsdb;

