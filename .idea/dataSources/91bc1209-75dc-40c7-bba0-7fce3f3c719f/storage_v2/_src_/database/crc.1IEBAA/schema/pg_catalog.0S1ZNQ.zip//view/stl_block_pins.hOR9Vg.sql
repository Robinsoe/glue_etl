create view stl_block_pins(logtime, query, slice, tbl, col, blocknum) as
SELECT stll_block_pins.logtime,
       stll_block_pins.query,
       stll_block_pins.slice,
       stll_block_pins.tbl,
       stll_block_pins.col,
       stll_block_pins.blocknum
FROM stll_block_pins;

alter table stl_block_pins
    owner to rdsdb;

