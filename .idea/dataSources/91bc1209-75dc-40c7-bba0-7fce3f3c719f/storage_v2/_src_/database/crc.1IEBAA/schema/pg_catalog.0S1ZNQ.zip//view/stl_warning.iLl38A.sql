create view stl_warning(userid, process, pid, recordtime, file, linenum, bug_desc) as
SELECT stll_warning.userid,
       stll_warning.process,
       stll_warning.pid,
       stll_warning.recordtime,
       stll_warning."file",
       stll_warning.linenum,
       stll_warning.bug_desc
FROM stll_warning;

alter table stl_warning
    owner to rdsdb;

