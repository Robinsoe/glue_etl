create view allwells_v
            (api10, api10_old, leasename, wellnumber, legal_well_name, wellstatus, welltype, operatorcode, operatorname,
             fieldname, areaname, district, countyname, section, township_number, township_direction, range_number,
             range_direction, basemeridian, latitude, longitude, espg_code, transform_code, target_code, gissource,
             isconfidential, isdirectional, spuddate, wellsymbol)
as
SELECT allwells.api                                                                            AS api10,
       COALESCE(c.old_api, allwells.api)                                                       AS api10_old,
       allwells.leasename,
       allwells.wellnumber,
       (allwells.leasename::text || ' '::character varying::text) || allwells.wellnumber::text AS legal_well_name,
       allwells.wellstatus,
       allwells.welltype,
       allwells.operatorco                                                                     AS operatorcode,
       allwells.operatorna                                                                     AS operatorname,
       allwells.fieldname,
       allwells.areaname,
       allwells.district,
       allwells.countyname,
       allwells.section,
       "left"(allwells.township::text, 2)                                                      AS township_number,
       "right"(allwells.township::text, 1)                                                     AS township_direction,
       "left"(allwells."range"::text, 2)                                                       AS range_number,
       "right"(allwells."range"::text, 1)                                                      AS range_direction,
       allwells.basemeridi                                                                     AS basemeridian,
       allwells.latitude,
       allwells.longitude,
       6319                                                                                    AS espg_code,
       1188                                                                                    AS transform_code,
       4326                                                                                    AS target_code,
       allwells.gissource,
       allwells.isconfiden                                                                     AS isconfidential,
       allwells.isdirectio                                                                     AS isdirectional,
       allwells.spuddate,
       allwells.wellsymbol
FROM calgem.allwells allwells
         LEFT JOIN calgem.old_new_api_number_changes c ON allwells.api::text = c.new_api::text;

alter table allwells_v
    owner to crc;

