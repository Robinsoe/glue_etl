create view stl_comm_pkt_latency
            (now, since, channel_type, src_node, dest_node, mean, stdev, min, max, total, ten_us, hundred_us, one_ms,
             ten_ms, hundred_ms, one_s, ten_s, inf)
as
SELECT stll_comm_pkt_latency.now,
       stll_comm_pkt_latency.since,
       stll_comm_pkt_latency.channel_type,
       stll_comm_pkt_latency.src_node,
       stll_comm_pkt_latency.dest_node,
       stll_comm_pkt_latency.mean,
       stll_comm_pkt_latency.stdev,
       stll_comm_pkt_latency.min,
       stll_comm_pkt_latency."max",
       stll_comm_pkt_latency.total,
       stll_comm_pkt_latency.ten_us,
       stll_comm_pkt_latency.hundred_us,
       stll_comm_pkt_latency.one_ms,
       stll_comm_pkt_latency.ten_ms,
       stll_comm_pkt_latency.hundred_ms,
       stll_comm_pkt_latency.one_s,
       stll_comm_pkt_latency.ten_s,
       stll_comm_pkt_latency.inf
FROM stll_comm_pkt_latency;

alter table stl_comm_pkt_latency
    owner to rdsdb;

