create view maximo_workorder (wonum, status, worktype, description, location, statusdate, supervisor) as
SELECT homax2p_maximo_workorder.wonum,
       homax2p_maximo_workorder.status,
       homax2p_maximo_workorder.worktype,
       homax2p_maximo_workorder.description2 AS description,
       homax2p_maximo_workorder."location",
       homax2p_maximo_workorder.statusdate,
       homax2p_maximo_workorder.supervisor
FROM homax2p_maximo_workorder
UNION
SELECT lgmax1p_maximo_workorder.wonum,
       lgmax1p_maximo_workorder.status,
       lgmax1p_maximo_workorder.worktype,
       lgmax1p_maximo_workorder.description2 AS description,
       lgmax1p_maximo_workorder."location",
       lgmax1p_maximo_workorder.statusdate,
       lgmax1p_maximo_workorder.supervisor
FROM lgmax1p_maximo_workorder;

alter table maximo_workorder
    owner to crc;

grant select on maximo_workorder to juan;

grant select on maximo_workorder to david;

