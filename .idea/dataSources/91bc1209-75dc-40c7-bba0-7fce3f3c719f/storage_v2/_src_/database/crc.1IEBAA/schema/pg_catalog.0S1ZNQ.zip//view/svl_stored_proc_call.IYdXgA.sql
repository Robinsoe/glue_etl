create view svl_stored_proc_call
            (userid, session_userid, query, label, xid, pid, database, querytxt, starttime, endtime, aborted,
             from_sp_call) as
SELECT spc.userid,
       spc.session_userid,
       spc.query,
       spc."label",
       spc.xid,
       spc.pid,
       spc."database",
       spc.querytxt,
       spc.starttime,
       spc.endtime,
       spc.aborted,
       spcm.from_sp_call
FROM stl_stored_proc_call spc
         LEFT JOIN stl_stored_proc_call_map spcm ON spc.query = spcm.query;

alter table svl_stored_proc_call
    owner to rdsdb;

