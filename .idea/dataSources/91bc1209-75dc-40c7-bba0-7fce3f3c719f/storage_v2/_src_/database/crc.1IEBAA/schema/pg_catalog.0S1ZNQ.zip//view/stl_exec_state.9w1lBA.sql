create view stl_exec_state
            (userid, query, slice, segment, step, starttime, currenttime, tasknum, rows, bytes, label, is_diskbased,
             workmem, num_parts, is_rrscan, is_delayed_scan)
as
SELECT stll_exec_state.userid,
       stll_exec_state.query,
       stll_exec_state.slice,
       stll_exec_state.segment,
       stll_exec_state.step,
       stll_exec_state.starttime,
       stll_exec_state.currenttime,
       stll_exec_state.tasknum,
       stll_exec_state."rows",
       stll_exec_state.bytes,
       stll_exec_state."label",
       stll_exec_state.is_diskbased,
       stll_exec_state.workmem,
       stll_exec_state.num_parts,
       stll_exec_state.is_rrscan,
       stll_exec_state.is_delayed_scan
FROM stll_exec_state;

alter table stl_exec_state
    owner to rdsdb;

