create function _pg_keypositions() returns integer
    immutable
    language sql
as
$$
    select g.s
        from generate_series(1,current_setting('max_index_keys')::int,1)
        as g(s)
$$;

