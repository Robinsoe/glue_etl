create view stl_userlog
            (userid, username, oldusername, action, usecreatedb, usesuper, usecatupd, valuntil, pid, xid, recordtime) as
SELECT stll_userlog.userid,
       stll_userlog.username,
       stll_userlog.oldusername,
       stll_userlog."action",
       stll_userlog.usecreatedb,
       stll_userlog.usesuper,
       stll_userlog.usecatupd,
       stll_userlog.valuntil,
       stll_userlog.pid,
       stll_userlog.xid,
       stll_userlog.recordtime
FROM stll_userlog;

alter table stl_userlog
    owner to rdsdb;

