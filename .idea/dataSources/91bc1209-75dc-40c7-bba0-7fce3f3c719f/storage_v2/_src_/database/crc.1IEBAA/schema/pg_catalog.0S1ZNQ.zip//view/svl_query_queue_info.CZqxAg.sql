create view svl_query_queue_info
            (database, query, xid, userid, querytxt, queue_start_time, exec_start_time, service_class, slots,
             queue_elapsed, exec_elapsed, wlm_total_elapsed, commit_queue_elapsed, commit_exec_time, service_class_name)
as
SELECT wd.db                        AS "database",
       wd.query,
       wd.xid,
       wd.userid,
       wd.querytxt,
       wd.queue_start_time,
       wd.exec_start_time,
       wd.service_class,
       wd.slots,
       wd.queue_seconds             AS queue_elapsed,
       wd.exec_seconds              AS exec_elapsed,
       wd.total_wlm_seconds         AS wlm_total_elapsed,
       ct.commit_queue_time_seconds AS commit_queue_elapsed,
       ct.commit_time_seconds       AS commit_exec_time,
       wd.service_class_name
FROM (SELECT swq.query,
             swq.xid,
             swq.userid,
             btrim(sq."database"::text)                             AS db,
             "substring"(sq.querytxt::text, 1, 100)                 AS querytxt,
             swq.service_class,
             swq.service_class_name,
             swq.queue_start_time,
             swq.exec_start_time,
             swq.slot_count                                         AS slots,
             swq.total_queue_time / 1000000                         AS queue_seconds,
             swq.total_exec_time / 1000000                          AS exec_seconds,
             (swq.total_queue_time + swq.total_exec_time) / 1000000 AS total_wlm_seconds
      FROM stl_wlm_query swq
               LEFT JOIN stl_query sq ON swq.query = sq.query
      WHERE swq.userid > 1) wd
         LEFT JOIN (SELECT scs.xid,
                           "max"(date_diff('microsec'::text,
                                           CASE
                                               WHEN scs.startqueue = '2000-01-01 00:00:00'::timestamp without time zone OR
                                                    scs.startqueue IS NULL AND '2000-01-01 00:00:00' IS NULL
                                                   THEN scs.startwork
                                               ELSE scs.startqueue
                                               END, scs.startwork)) / 1000000                       AS commit_queue_time_seconds,
                           "max"(date_diff('microsec'::text, scs.startwork, scs.endtime)) /
                           1000000                                                                  AS commit_time_seconds
                    FROM stl_commit_stats scs
                    GROUP BY scs.xid) ct ON wd.xid = ct.xid
WHERE wd.queue_seconds > 0
   OR COALESCE(ct.commit_queue_time_seconds, 0::bigint) > 0;

alter table svl_query_queue_info
    owner to rdsdb;

