create view mv_tbldatahistory(nodeid, date, address, value, xspoc_source, p_2) as
CREATE MATERIALIZED VIEW xspoc_high_res_views.mv_tbldatahistory AS
SELECT nodeid, date, address, value, partition_1 xspoc_source, max(partition_2) p_2
FROM xspoc_high_res.tbldatahistory
GROUP BY address, nodeid, value, date, partition_1;

alter table mv_tbldatahistory
    owner to crc;

