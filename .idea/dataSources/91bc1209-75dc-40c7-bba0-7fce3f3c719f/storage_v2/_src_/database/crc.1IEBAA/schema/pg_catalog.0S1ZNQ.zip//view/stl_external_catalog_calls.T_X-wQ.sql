create view stl_external_catalog_calls
            (userid, query, uuid, segment, node, slice, eventtime, call, objects, duration) as
SELECT stll_external_catalog_calls.userid,
       stll_external_catalog_calls.query,
       stll_external_catalog_calls.uuid,
       stll_external_catalog_calls.segment,
       stll_external_catalog_calls.node,
       stll_external_catalog_calls.slice,
       stll_external_catalog_calls.eventtime,
       stll_external_catalog_calls."call",
       stll_external_catalog_calls.objects,
       stll_external_catalog_calls.duration
FROM stll_external_catalog_calls;

alter table stl_external_catalog_calls
    owner to rdsdb;

