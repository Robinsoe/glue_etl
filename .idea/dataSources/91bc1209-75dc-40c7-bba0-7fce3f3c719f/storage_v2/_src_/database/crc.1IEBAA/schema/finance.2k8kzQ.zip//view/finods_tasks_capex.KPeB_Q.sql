create view finods_tasks_capex
            (task_id, task_cd, task_name, top_task_id, parent_task_id, description, task_template, task_number,
             wbs_level) as
SELECT a.task_id,
       a.task_number AS task_cd,
       a.task_name,
       a.top_task_id,
       a.parent_task_id,
       a.description,
       b.name        AS task_template,
       a.task_number,
       a.wbs_level
FROM pa_pa_tasks a
         JOIN pa_pa_projects_all b ON a.project_id = b.project_id
WHERE b.segment1::text ~~ 'T%'::character varying::text
  AND b.project_type::text ~~ '%Capital%'::character varying::text
  AND (b.template_end_date_active >= 'now'::text::date OR b.template_end_date_active IS NULL);

alter table finods_tasks_capex
    owner to crc;

grant select on finods_tasks_capex to juan;

grant select on finods_tasks_capex to david;

grant select on finods_tasks_capex to isabel;

