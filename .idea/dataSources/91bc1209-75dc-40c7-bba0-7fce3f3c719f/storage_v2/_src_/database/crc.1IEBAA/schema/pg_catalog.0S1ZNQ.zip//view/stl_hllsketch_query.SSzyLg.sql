create view stl_hllsketch_query(userid, query, starttime, endtime, query_cmd_type, aborted) as
SELECT stll_hllsketch_query.userid,
       stll_hllsketch_query.query,
       stll_hllsketch_query.starttime,
       stll_hllsketch_query.endtime,
       stll_hllsketch_query.query_cmd_type,
       stll_hllsketch_query.aborted
FROM stll_hllsketch_query;

alter table stl_hllsketch_query
    owner to rdsdb;

