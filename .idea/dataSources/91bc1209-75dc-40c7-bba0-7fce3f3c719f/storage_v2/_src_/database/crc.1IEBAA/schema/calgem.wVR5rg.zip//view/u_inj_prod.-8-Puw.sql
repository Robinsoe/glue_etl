create view u_inj_prod
            (api10, reportdate, gas_airinjected_mcf, steam_waterinjected_bbl, oilorcondensateproduced, gasproduced_mcf,
             waterproduced_bbl)
as
SELECT u_inj.api10,
       u_inj.injectiondate AS reportdate,
       u_inj.gas_airinjected_mcf,
       u_inj.steam_waterinjected_bbl,
       0.0                 AS oilorcondensateproduced,
       0.0                 AS gasproduced_mcf,
       0.0                 AS waterproduced_bbl
FROM calgem.u_inj
UNION
SELECT u_prod.api10,
       u_prod.productiondate AS reportdate,
       0.0                   AS gas_airinjected_mcf,
       0.0                   AS steam_waterinjected_bbl,
       u_prod.oilorcondensateproduced,
       u_prod.gasproduced_mcf,
       u_prod.waterproduced_bbl
FROM calgem.u_prod;

alter table u_inj_prod
    owner to crc;

