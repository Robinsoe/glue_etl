create view stl_plan_state(query, component, state, detail, label) as
SELECT stll_plan_state.query,
       stll_plan_state.component,
       stll_plan_state.state,
       stll_plan_state.detail,
       stll_plan_state."label"
FROM stll_plan_state;

alter table stl_plan_state
    owner to rdsdb;

