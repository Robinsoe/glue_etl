create view svl_burst_service_client (action, pid, xid, eventtime, cluster_arn, expiration, num_nodes, error) as
SELECT stl_burst_service_client."action",
       stl_burst_service_client.pid,
       stl_burst_service_client.xid,
       stl_burst_service_client.eventtime,
       stl_burst_service_client.cluster_arn,
       stl_burst_service_client.expiration,
       stl_burst_service_client.num_nodes,
       stl_burst_service_client.error
FROM stl_burst_service_client;

alter table svl_burst_service_client
    owner to rdsdb;

