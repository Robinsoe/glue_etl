create view stl_leader_snapshot(currenttime, num_snapshot_blocks) as
SELECT stll_leader_snapshot.currenttime, stll_leader_snapshot.num_snapshot_blocks
FROM stll_leader_snapshot;

alter table stl_leader_snapshot
    owner to rdsdb;

