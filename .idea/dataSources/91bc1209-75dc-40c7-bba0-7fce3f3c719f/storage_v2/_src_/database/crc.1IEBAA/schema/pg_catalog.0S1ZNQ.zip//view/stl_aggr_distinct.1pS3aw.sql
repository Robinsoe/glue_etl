create view stl_aggr_distinct
            (query, slice, segment, step, col, rows, bytes, slots, occupied, maxlength, tbl, is_diskbased, resizes,
             flushable) as
SELECT stll_aggr_distinct.query,
       stll_aggr_distinct.slice,
       stll_aggr_distinct.segment,
       stll_aggr_distinct.step,
       stll_aggr_distinct.col,
       stll_aggr_distinct."rows",
       stll_aggr_distinct.bytes,
       stll_aggr_distinct.slots,
       stll_aggr_distinct.occupied,
       stll_aggr_distinct.maxlength,
       stll_aggr_distinct.tbl,
       stll_aggr_distinct.is_diskbased,
       stll_aggr_distinct.resizes,
       stll_aggr_distinct.flushable
FROM stll_aggr_distinct;

alter table stl_aggr_distinct
    owner to rdsdb;

