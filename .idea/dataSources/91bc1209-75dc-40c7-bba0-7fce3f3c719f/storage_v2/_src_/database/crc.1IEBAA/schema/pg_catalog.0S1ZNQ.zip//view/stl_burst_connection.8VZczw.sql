create view stl_burst_connection
            (action, method, pid, xid, line_number, eventtime, cluster_arn, connection_guid, error, switch_status,
             switch_time, starttime)
as
SELECT stll_burst_connection."action",
       stll_burst_connection.method,
       stll_burst_connection.pid,
       stll_burst_connection.xid,
       stll_burst_connection.line_number,
       stll_burst_connection.eventtime,
       stll_burst_connection.cluster_arn,
       stll_burst_connection.connection_guid,
       stll_burst_connection.error,
       stll_burst_connection.switch_status,
       stll_burst_connection.switch_time,
       stll_burst_connection.starttime
FROM stll_burst_connection;

alter table stl_burst_connection
    owner to rdsdb;

