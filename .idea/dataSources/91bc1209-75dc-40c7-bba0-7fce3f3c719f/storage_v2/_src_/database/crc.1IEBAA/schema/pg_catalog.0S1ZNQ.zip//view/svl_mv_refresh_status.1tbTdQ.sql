create view svl_mv_refresh_status
            (db_name, userid, schema_name, mv_name, xid, starttime, endtime, status, refresh_type) as
SELECT e.datname AS db_name,
       a.userid,
       b.nspname AS schema_name,
       d.relname AS mv_name,
       a.xid,
       a.starttime,
       a.endtime,
       CASE
           WHEN a.status = -8 THEN 'Refresh failed due to an internal error'::text
           WHEN a.status = -7 THEN 'Refresh failed. Schema of MV was renamed'::text
           WHEN a.status = -6 THEN 'Refresh failed. A base table column was renamed'::text
           WHEN a.status = -5 THEN 'Refresh failed. A base table was renamed'::text
           WHEN a.status = -4 THEN 'Refresh failed. A base table column type was changed'::text
           WHEN a.status = -3 THEN 'Refresh failed. A base table column was dropped'::text
           WHEN a.status = -2 THEN 'Refresh failed. MV was not found'::text
           WHEN a.status = -1 THEN 'Refresh failed due to an internal error'::text
           WHEN a.status = 1 THEN 'Refresh successfully updated MV incrementally'::text
           WHEN a.status = 2 THEN 'MV was already updated'::text
           WHEN a.status = 3 THEN 'Refresh successfully recomputed MV from scratch'::text
           WHEN a.status = 4 THEN 'Refresh could not update MV further due to an active transaction'::text
           WHEN a.status = 5 THEN 'Refresh partially updated MV incrementally up to an active transaction'::text
           WHEN a.status = 6 THEN 'Refresh partially recomputed MV from scratch up to an active transaction'::text
           ELSE 'Unknown refresh status'::text
           END   AS status,
       a.refresh_type
FROM stl_mv_refresh a,
     pg_namespace b,
     pg_class d,
     pg_database e
WHERE a.schemaoid::oid = b.oid
  AND a.mvoid::oid = d.oid
  AND a.db_oid::oid = e.oid;

alter table svl_mv_refresh_status
    owner to rdsdb;

