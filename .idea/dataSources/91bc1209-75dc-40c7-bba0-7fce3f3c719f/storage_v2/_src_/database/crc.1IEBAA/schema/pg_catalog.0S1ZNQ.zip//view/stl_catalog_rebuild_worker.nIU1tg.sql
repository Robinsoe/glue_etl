create view stl_catalog_rebuild_worker
            (xid, pid, database, total_live_tup_sz, total_dead_tup_sz, starttime, endtime, num_rebuilds_reqd,
             rebuild_triggered, last_rebuild_time, rebuild_needed_duration, force_lock, exception)
as
SELECT stll_catalog_rebuild_worker.xid,
       stll_catalog_rebuild_worker.pid,
       stll_catalog_rebuild_worker."database",
       stll_catalog_rebuild_worker.total_live_tup_sz,
       stll_catalog_rebuild_worker.total_dead_tup_sz,
       stll_catalog_rebuild_worker.starttime,
       stll_catalog_rebuild_worker.endtime,
       stll_catalog_rebuild_worker.num_rebuilds_reqd,
       stll_catalog_rebuild_worker.rebuild_triggered,
       stll_catalog_rebuild_worker.last_rebuild_time,
       stll_catalog_rebuild_worker.rebuild_needed_duration,
       stll_catalog_rebuild_worker.force_lock,
       stll_catalog_rebuild_worker.exception
FROM stll_catalog_rebuild_worker;

alter table stl_catalog_rebuild_worker
    owner to rdsdb;

