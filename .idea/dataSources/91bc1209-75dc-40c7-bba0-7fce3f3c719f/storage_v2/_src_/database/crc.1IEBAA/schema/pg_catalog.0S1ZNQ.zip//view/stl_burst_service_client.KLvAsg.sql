create view stl_burst_service_client
            (action, pid, xid, eventtime, cluster_arn, expiration, preshared_key, num_nodes, error, request_id,
             reason) as
SELECT stll_burst_service_client."action",
       stll_burst_service_client.pid,
       stll_burst_service_client.xid,
       stll_burst_service_client.eventtime,
       stll_burst_service_client.cluster_arn,
       stll_burst_service_client.expiration,
       stll_burst_service_client.preshared_key,
       stll_burst_service_client.num_nodes,
       stll_burst_service_client.error,
       stll_burst_service_client.request_id,
       stll_burst_service_client.reason
FROM stll_burst_service_client;

alter table stl_burst_service_client
    owner to rdsdb;

