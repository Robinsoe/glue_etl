create view maximo_workorder_v
            (wonum, status, active_flag, worktype, description, location, statusdate, supervisor, max_name) as
SELECT maximo_workorder.wonum,
       maximo_workorder.status,
       CASE
           WHEN maximo_workorder.status::text = 'APPR'::character varying::text OR
                maximo_workorder.status::text = 'COMP'::character varying::text OR
                maximo_workorder.status::text = 'INPRG'::character varying::text OR
                maximo_workorder.status::text = 'WMATL'::character varying::text OR
                maximo_workorder.status::text = 'WSCH'::character varying::text THEN 'Y'::character varying
           ELSE 'N'::character varying
           END                                            AS active_flag,
       maximo_workorder.worktype,
       maximo_workorder.description,
       maximo_workorder."location",
       maximo_workorder.statusdate,
       maximo_workorder.supervisor,
       COALESCE(p.full_name, maximo_workorder.supervisor) AS max_name
FROM maximo_workorder
         LEFT JOIN (SELECT DISTINCT upper(hr_per_all_people_f.attribute1::text) AS alias,
                                    hr_per_all_people_f.person_id,
                                    hr_per_all_people_f.full_name
                    FROM hr_per_all_people_f
                    WHERE hr_per_all_people_f.local_name::text !~~
                          '%DNU%'::character varying::text) p(alias, person_id, full_name)
                   ON maximo_workorder.supervisor::text = p.alias;

alter table maximo_workorder_v
    owner to crc;

grant select on maximo_workorder_v to juan;

grant select on maximo_workorder_v to david;

