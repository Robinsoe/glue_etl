create view stl_restore
            (db_name, xid, seq, backup_name, backup_label, source_cluster_name, source_db_name, source_backup_starttime,
             backup_type, starttime, endtime, succeeded)
as
SELECT stll_restore.db_name,
       stll_restore.xid,
       stll_restore.seq,
       stll_restore.backup_name,
       stll_restore.backup_label,
       stll_restore.source_cluster_name,
       stll_restore.source_db_name,
       stll_restore.source_backup_starttime,
       stll_restore.backup_type,
       stll_restore.starttime,
       stll_restore.endtime,
       stll_restore.succeeded
FROM stll_restore;

alter table stl_restore
    owner to rdsdb;

