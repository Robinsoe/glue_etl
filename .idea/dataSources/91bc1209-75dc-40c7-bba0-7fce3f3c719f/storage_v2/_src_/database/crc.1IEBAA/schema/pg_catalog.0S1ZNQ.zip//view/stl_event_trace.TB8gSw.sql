create view stl_event_trace (event, eventtime, sliceid, pid, file, linenum, message, event_name, level) as
SELECT stll_event_trace.event,
       stll_event_trace.eventtime,
       stll_event_trace.sliceid,
       stll_event_trace.pid,
       stll_event_trace."file",
       stll_event_trace.linenum,
       stll_event_trace.message,
       stll_event_trace.event_name,
       stll_event_trace."level"
FROM stll_event_trace;

alter table stl_event_trace
    owner to rdsdb;

