create view stl_alter_column_events
            (userid, xid, pid, logtime, command_type, tbl_id, tbl_name, col_id, col_name, src_type, src_typemod,
             tgt_type, tgt_typemod)
as
SELECT stll_alter_column_events.userid,
       stll_alter_column_events.xid,
       stll_alter_column_events.pid,
       stll_alter_column_events.logtime,
       stll_alter_column_events.command_type,
       stll_alter_column_events.tbl_id,
       stll_alter_column_events.tbl_name,
       stll_alter_column_events.col_id,
       stll_alter_column_events.col_name,
       stll_alter_column_events.src_type,
       stll_alter_column_events.src_typemod,
       stll_alter_column_events.tgt_type,
       stll_alter_column_events.tgt_typemod
FROM stll_alter_column_events;

alter table stl_alter_column_events
    owner to rdsdb;

