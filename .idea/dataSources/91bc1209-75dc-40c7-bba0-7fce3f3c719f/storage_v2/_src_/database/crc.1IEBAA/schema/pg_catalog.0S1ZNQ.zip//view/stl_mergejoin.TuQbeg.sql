create view stl_mergejoin
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, tbl, checksum, distribution) as
SELECT stll_mergejoin.userid,
       stll_mergejoin.query,
       stll_mergejoin.slice,
       stll_mergejoin.segment,
       stll_mergejoin.step,
       stll_mergejoin.starttime,
       stll_mergejoin.endtime,
       stll_mergejoin.tasknum,
       stll_mergejoin."rows",
       stll_mergejoin.tbl,
       stll_mergejoin.checksum,
       stll_mergejoin.distribution
FROM stll_mergejoin;

alter table stl_mergejoin
    owner to rdsdb;

