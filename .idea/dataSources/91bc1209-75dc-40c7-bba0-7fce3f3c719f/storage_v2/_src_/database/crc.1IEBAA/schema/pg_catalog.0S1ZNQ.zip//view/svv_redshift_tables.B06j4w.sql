create view svv_redshift_tables (database_name, schema_name, table_name, table_type, table_acl, remarks) as
SELECT current_database()::character varying(128)                     AS database_name,
       pns.nspname::character varying(128)                            AS schema_name,
       pgc.relname::character varying(128)                            AS table_name,
       CASE
           WHEN pns.nspname ~~ like_escape('pg!_temp!_%'::text, '!'::text) THEN 'LOCAL TEMPORARY'::text
           WHEN pgc.relkind = 'r'::"char" THEN 'TABLE'::text
           WHEN pgc.relkind = 'v'::"char" THEN 'VIEW'::text
           ELSE NULL::text
           END::character varying                                     AS table_type,
       array_to_string(pgc.relacl, '~'::text)::character varying(128) AS table_acl,
       d.description::character varying                               AS remarks
FROM pg_namespace pns
         JOIN pg_class pgc ON pgc.relnamespace = pns.oid
         LEFT JOIN pg_description d ON pgc.oid = d.objoid AND d.objsubid = 0
WHERE (pgc.relkind = 'r'::"char" OR pgc.relkind = 'v'::"char")
  AND has_schema_privilege("current_user"()::name, pns.nspname::text, 'USAGE'::text)
  AND (has_table_privilege("current_user"()::name, pgc.oid, 'SELECT'::text) OR
       has_any_column_privilege("current_user"()::name, pgc.oid, 'SELECT'::text))
  AND pns.nspname <> 'catalog_history'::name
  AND pns.nspname <> 'pg_toast'::name
  AND pns.nspname <> 'pg_internal'::name
  AND pns.nspname !~~ 'pg_temp%'::text
UNION ALL
SELECT btrim(rs_tables.database_name::text)::character varying(128) AS database_name,
       btrim(rs_tables.schema_name::text)::character varying(128)   AS schema_name,
       btrim(rs_tables.table_name::text)::character varying(128)    AS table_name,
       btrim(rs_tables.table_type::text)::character varying(128)    AS table_type,
       btrim(rs_tables.table_acl::text)::character varying(128)     AS table_acl,
       btrim(rs_tables.remarks::text)::character varying(128)       AS remarks
FROM pg_get_shared_redshift_tables() rs_tables(database_name character varying, schema_name character varying,
                                               table_name character varying, table_type character varying,
                                               table_acl character varying, remarks character varying)
ORDER BY 1, 2, 3;

alter table svv_redshift_tables
    owner to rdsdb;

