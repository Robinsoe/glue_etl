create view stl_memory_pressure_actions
            (now, node, memory_type, action_type, state, process_type, query, pid, shared_mem_used, heap_mem_used,
             pinned_blocks_mem_used, src_pid)
as
SELECT stll_memory_pressure_actions.now,
       stll_memory_pressure_actions.node,
       stll_memory_pressure_actions.memory_type,
       stll_memory_pressure_actions.action_type,
       stll_memory_pressure_actions.state,
       stll_memory_pressure_actions.process_type,
       stll_memory_pressure_actions.query,
       stll_memory_pressure_actions.pid,
       stll_memory_pressure_actions.shared_mem_used,
       stll_memory_pressure_actions.heap_mem_used,
       stll_memory_pressure_actions.pinned_blocks_mem_used,
       stll_memory_pressure_actions.src_pid
FROM stll_memory_pressure_actions;

alter table stl_memory_pressure_actions
    owner to rdsdb;

