create view stl_plan_perf (query, sequence, component, count, udc, total_time, max_time, min_time, avg_time) as
SELECT stll_plan_perf.query,
       stll_plan_perf."sequence",
       stll_plan_perf.component,
       stll_plan_perf.count,
       stll_plan_perf.udc,
       stll_plan_perf.total_time,
       stll_plan_perf.max_time,
       stll_plan_perf.min_time,
       stll_plan_perf.avg_time
FROM stll_plan_perf;

alter table stl_plan_perf
    owner to rdsdb;

