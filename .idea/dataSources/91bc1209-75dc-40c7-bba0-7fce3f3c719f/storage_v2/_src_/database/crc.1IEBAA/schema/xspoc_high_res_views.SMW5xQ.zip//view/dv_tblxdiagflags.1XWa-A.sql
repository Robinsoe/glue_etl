CREATE VIEW xspoc_high_res_views.dv_tblxdiagflags AS
SELECT "nodeid"
     , "date"
     , "pumpfillage"
     , "mbalancede"
     , "grosspumpstroke"
     , "origcrankhole"
     , "hittingup"
     , "plungertoosmall"
     , "rodsoverloaded"
     , "fluidpound"
     , "incompletefillage"
     , "spmlow"
     , "tubingmovement"
     , "loadshift"
     , "kinematicstroke"
     , "sectfluidvelocity"
     , "pumpfriction"
     , "severedownholeproblem"
     , "mbalancedt"
     , "tubinganchored"
     , "fluidvelocity"
     , "mexisting"
     , "wornpumpbarrel"
     , "maxrodstressl"
     , "gearboxloadingbalancede"
     , "electricbillpermonthbalancedt"
     , "fullpump"
     , "incorrectfluidspgr"
     , "gasinterference"
     , "bentpumpbarrel"
     , "incorrectproductionrate"
     , "incorrectspm"
     , "gearboxloadingbalancedt"
     , "electricbillpermonthexisting"
     , "malfunctioningtubinganchor"
     , "maxfluidspgr"
     , "clamponloadcell"
     , "wornpump"
     , "phaseadjustment"
     , "plungertoolarge"
     , "tvleak"
     , "surfacematchpoor"
     , "rodstringcompressed"
     , "calcfrictionstatus"
     , "xdlinesseth"
     , "rodtubingfriction"
     , "sysdiagfluidspgr"
     , "crankholecorrected"
     , "unknownpumpcondition"
     , "grossproduction"
     , "tubinganchorloose"
     , "measuredstroke"
     , "pgrosspumpstroke"
     , "plungersize"
     , "pumpintakepressure"
     , "hittingdown"
     , "feetfromsurface"
     , "clamponineleganthackhackpc"
     , "pumpconditiongood"
     , "clampon"
     , "xdfeetfromsurface"
     , "origstrokelength"
     , "spmhigh"
     , "loadshiftpct"
     , "incorrectplungersize"
     , "gaslock"
     , "excessiverodtubingfriction"
     , "tubingleak"
     , "loadshiftcorrected"
     , "calcfluidspgr"
     , "svleak"
     , "surfposkinematiccorrected"
     , "surfposkinematicrequired"
     , "numrods"
     , "fluidlevelcorrected"
     , "shallowfriction"
     , "upperringvalvepump"
     , "crankhole"
     , "electricbillpermonthbalancede"
     , "unknownm"
     , "stuckpump"
     , "fluidspgr"
     , "sinkerbarwavereflection"
     , "rodpart"
     , "fluidinertia"
     , "extremerodtubingfriction"
     , "diagrodpart"
     , "adjustphase"
     , "fluidlevelsource"
     , "gearboxloadingexisting"
     , "measuredstrokecorrected"
     , "partition_1"        "xspoc_source"
     , "max"("partition_2") "p_2"
FROM xspoc_high_res.tblxdiagflags
GROUP BY "pumpfillage", "mbalancede", "grosspumpstroke", "origcrankhole", "hittingup", "plungertoosmall",
         "rodsoverloaded", "fluidpound", "incompletefillage", "spmlow", "tubingmovement", "loadshift",
         "kinematicstroke", "sectfluidvelocity", "pumpfriction", "severedownholeproblem", "mbalancedt",
         "tubinganchored", "fluidvelocity", "mexisting", "wornpumpbarrel", "maxrodstressl", "gearboxloadingbalancede",
         "electricbillpermonthbalancedt", "fullpump", "incorrectfluidspgr", "gasinterference", "bentpumpbarrel",
         "incorrectproductionrate", "incorrectspm", "gearboxloadingbalancedt", "electricbillpermonthexisting",
         "malfunctioningtubinganchor", "maxfluidspgr", "clamponloadcell", "wornpump", "phaseadjustment",
         "plungertoolarge", "tvleak", "surfacematchpoor", "rodstringcompressed", "calcfrictionstatus", "xdlinesseth",
         "rodtubingfriction", "sysdiagfluidspgr", "crankholecorrected", "unknownpumpcondition", "grossproduction",
         "tubinganchorloose", "measuredstroke", "pgrosspumpstroke", "plungersize", "pumpintakepressure", "hittingdown",
         "feetfromsurface", "clamponineleganthackhackpc", "pumpconditiongood", "clampon", "xdfeetfromsurface",
         "origstrokelength", "nodeid", "spmhigh", "loadshiftpct", "incorrectplungersize", "gaslock",
         "excessiverodtubingfriction", "tubingleak", "loadshiftcorrected", "calcfluidspgr", "svleak",
         "surfposkinematiccorrected", "surfposkinematicrequired", "numrods", "fluidlevelcorrected", "shallowfriction",
         "upperringvalvepump", "crankhole", "electricbillpermonthbalancede", "unknownm", "date", "stuckpump",
         "fluidspgr", "sinkerbarwavereflection", "rodpart", "fluidinertia", "extremerodtubingfriction", "diagrodpart",
         "adjustphase", "fluidlevelsource", "gearboxloadingexisting", "measuredstrokecorrected", "partition_1"
ORDER BY "nodeid" ASC, "date" DESC
with no schema binding;

alter table dv_tblxdiagflags
    owner to crc;

