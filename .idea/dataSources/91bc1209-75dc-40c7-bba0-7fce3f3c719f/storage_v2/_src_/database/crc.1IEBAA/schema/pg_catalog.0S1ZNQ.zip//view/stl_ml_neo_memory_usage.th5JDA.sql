create view stl_ml_neo_memory_usage
            (record_time, node, query, slice, pid, model_name, model_path, model_type, num_inputs, num_outputs,
             file_size, mem_used, dlr_version)
as
SELECT stll_ml_neo_memory_usage.record_time,
       stll_ml_neo_memory_usage.node,
       stll_ml_neo_memory_usage.query,
       stll_ml_neo_memory_usage.slice,
       stll_ml_neo_memory_usage.pid,
       stll_ml_neo_memory_usage.model_name,
       stll_ml_neo_memory_usage.model_path,
       stll_ml_neo_memory_usage.model_type,
       stll_ml_neo_memory_usage.num_inputs,
       stll_ml_neo_memory_usage.num_outputs,
       stll_ml_neo_memory_usage.file_size,
       stll_ml_neo_memory_usage.mem_used,
       stll_ml_neo_memory_usage.dlr_version
FROM stll_ml_neo_memory_usage;

alter table stl_ml_neo_memory_usage
    owner to rdsdb;

