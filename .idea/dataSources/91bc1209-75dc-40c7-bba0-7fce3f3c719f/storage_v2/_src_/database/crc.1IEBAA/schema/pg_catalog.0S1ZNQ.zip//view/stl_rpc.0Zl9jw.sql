create view stl_rpc (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, requests, rpc_type) as
SELECT stll_rpc.userid,
       stll_rpc.query,
       stll_rpc.slice,
       stll_rpc.segment,
       stll_rpc.step,
       stll_rpc.starttime,
       stll_rpc.endtime,
       stll_rpc.tasknum,
       stll_rpc."rows",
       stll_rpc.requests,
       stll_rpc.rpc_type
FROM stll_rpc;

alter table stl_rpc
    owner to rdsdb;

