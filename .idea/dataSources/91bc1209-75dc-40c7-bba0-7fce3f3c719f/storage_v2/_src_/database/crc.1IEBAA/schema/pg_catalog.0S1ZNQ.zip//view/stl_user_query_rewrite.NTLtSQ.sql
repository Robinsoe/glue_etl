create view stl_user_query_rewrite(user_query_id, rewritten_query_id, sequence) as
SELECT stll_user_query_rewrite.user_query_id,
       stll_user_query_rewrite.rewritten_query_id,
       stll_user_query_rewrite."sequence"
FROM stll_user_query_rewrite;

alter table stl_user_query_rewrite
    owner to rdsdb;

