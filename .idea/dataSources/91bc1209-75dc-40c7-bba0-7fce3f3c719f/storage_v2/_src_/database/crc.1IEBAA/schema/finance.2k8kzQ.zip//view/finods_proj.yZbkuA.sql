create view finods_proj (project_cd, project_id, project_name, cost_center, template_name, cost_center_v) as
SELECT ppa.segment1                       AS project_cd,
       ppa.project_id,
       "substring"(ppa.name::text, 1, 30) AS project_name,
       ppa.attribute1::bigint             AS cost_center,
       ppa2.name                          AS template_name,
       ppa.attribute1                     AS cost_center_v
FROM pa_pa_projects_all ppa
         JOIN pa_pa_projects_all ppa2 ON ppa.created_from_project_id = ppa2.project_id
WHERE ppa2.template_flag::text = 'Y'::text;

alter table finods_proj
    owner to crc;

grant select on finods_proj to juan;

grant select on finods_proj to david;

grant select on finods_proj to isabel;

