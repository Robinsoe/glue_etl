create view pg_user_info
            (usename, usesysid, usecreatedb, usesuper, usecatupd, passwd, valuntil, useconfig, useconnlimit) as
SELECT pg_shadow.usename,
       pg_shadow.usesysid,
       pg_shadow.usecreatedb,
       pg_shadow.usesuper,
       pg_shadow.usecatupd,
       '********'::character varying AS passwd,
       pg_shadow.valuntil,
       pg_shadow.useconfig,
       CASE
           WHEN pse_col1.value = (- 1::smallint)::text THEN 'UNLIMITED'::text
           ELSE pse_col1.value
           END                       AS useconnlimit
FROM pg_shadow
         LEFT JOIN pg_shadow_extended pse_col1 ON pg_shadow.usesysid = pse_col1."sysid" AND pse_col1.colnum = 1
WHERE pg_shadow.usename !~~ 'f346c9b8%'::text;

alter table pg_user_info
    owner to rdsdb;

