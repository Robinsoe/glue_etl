create view stl_alter_column_encode_events
            (userid, vpid, logtime, slice, xid, command_phase, tbl_id, tbl_name, col_id, col_name, shadow_col_id,
             src_encode, tgt_encode, scan_rows)
as
SELECT stll_alter_column_encode_events.userid,
       stll_alter_column_encode_events.vpid,
       stll_alter_column_encode_events.logtime,
       stll_alter_column_encode_events.slice,
       stll_alter_column_encode_events.xid,
       stll_alter_column_encode_events.command_phase,
       stll_alter_column_encode_events.tbl_id,
       stll_alter_column_encode_events.tbl_name,
       stll_alter_column_encode_events.col_id,
       stll_alter_column_encode_events.col_name,
       stll_alter_column_encode_events.shadow_col_id,
       stll_alter_column_encode_events.src_encode,
       stll_alter_column_encode_events.tgt_encode,
       stll_alter_column_encode_events.scan_rows
FROM stll_alter_column_encode_events;

alter table stl_alter_column_encode_events
    owner to rdsdb;

