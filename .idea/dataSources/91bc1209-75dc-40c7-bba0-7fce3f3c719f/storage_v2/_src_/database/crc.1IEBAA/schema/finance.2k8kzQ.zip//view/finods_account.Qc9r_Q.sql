create view finods_account (acct_id, acct_cd, acct_desc, hyperion_acct_cd, user_name, last_update_date) as
SELECT a.acct_id, a.acct_cd, a.acct_desc, a.hyperion_acct_cd, u.user_name, a.last_update_date
FROM xxoxycommon_oxycmnshr_account a
         LEFT JOIN applsys_fnd_user u ON u.user_id::numeric = a.last_updated_by;

alter table finods_account
    owner to crc;

grant select on finods_account to juan;

grant select on finods_account to david;

grant select on finods_account to isabel;

