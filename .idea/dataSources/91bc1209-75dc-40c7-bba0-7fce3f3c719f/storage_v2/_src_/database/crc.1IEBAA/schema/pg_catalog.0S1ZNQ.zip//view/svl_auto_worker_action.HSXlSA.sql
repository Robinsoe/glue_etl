create view svl_auto_worker_action(table_id, type, status, eventtime, sequence, previous_state) as
SELECT stl_auto_alter_worker_event.tbl AS table_id,
       CASE
           WHEN stl_auto_alter_worker_event.recommend = 23 THEN 'distkey'::text
           WHEN stl_auto_alter_worker_event.recommend = 24 THEN 'sortkey'::text
           ELSE NULL::text
           END                         AS "type",
       CASE
           WHEN stl_auto_alter_worker_event.status ~~ '%Under%'::text THEN 'Failed'::bpchar
           WHEN stl_auto_alter_worker_event.status ~~ '%Exception%'::text THEN 'Failed'::bpchar
           ELSE stl_auto_alter_worker_event.status
           END                         AS status,
       stl_auto_alter_worker_event.eventtime,
       stl_auto_alter_worker_event."sequence",
       stl_auto_alter_worker_event.previous_state
FROM stl_auto_alter_worker_event;

alter table svl_auto_worker_action
    owner to rdsdb;

