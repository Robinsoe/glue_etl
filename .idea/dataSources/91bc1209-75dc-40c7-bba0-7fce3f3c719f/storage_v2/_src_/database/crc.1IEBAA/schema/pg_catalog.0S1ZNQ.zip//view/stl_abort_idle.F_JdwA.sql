create view stl_abort_idle(xid, idle_start_time, idle_check_time, txn_start_time, aborted) as
SELECT stll_abort_idle.xid,
       stll_abort_idle.idle_start_time,
       stll_abort_idle.idle_check_time,
       stll_abort_idle.txn_start_time,
       stll_abort_idle.aborted
FROM stll_abort_idle;

alter table stl_abort_idle
    owner to rdsdb;

