create or replace view finance.doe_v2 AS
SELECT a.book_date                               as book_date,
       bu.business_unit                          as business_unit,
       a.creation_date                           as creation_date,
       a.project_cd                              as project_cd,
       a.company_cd                              as company_cd,
       a.cost_center                             as cost_center,
       a.element_cd                              as element_cd,
       a.task_cd                                 as task_cd,
       a.task_template                           as task_template,
       a.acct_cd                                 as acct_cd,
       a.clearing_no                             as clearing_no,
       a.line_no                                 as line_no,
       a.line_desc                               as line_desc,
       a.jva_bill_code                           as jva_bill_code,
       a.je_batch_name                           as je_batch_name,
       a.task_name                               as task_name,
       a.default_cost_center                     as default_cost_center,
       a.vendor_name                             as vendor_name,
       a.invoice_no                              as invoice_no,
       a.invoice_date                            as invoice_date,
       a.trans_source                            as trans_source,
       a.desc_lines                              as desc_lines,
       a.vendor_no                               as vendor_no,
       a.job_no                                  as job_no,
       a.attachment1                             as attachment1,
       a.attachment2                             as attachment2,
       a.attachment3                             as attachment3,
       a.attachment4                             as attachment4,
       b.cost_center_name                        as cost_center_name,
       b.at_name                                 as at_name,
       b.subat_name                              as subat_name,
       b.orglev4_name                            as orglev4_name,
       b.orglev5_name                            as orglev5_name,
       c.element_lvl1_name                       as element_lvl1_name,
       c.element_lvl2_name                       as element_lvl2_name,
       c.element_lvl3_name                       as element_lvl3_name,
       c.element_lvl4_name                       as element_lvl4_name,
       c.element_lvl5_name                       as element_lvl5_name,
       d.hyperion_acct_cd_short                  as hyperion_acct_cd_short,
       d.hyperion_desc                           as hyperion_desc,
       e.name                                    AS project_name,
       e.project_type                            AS template_name,
       f.acct_desc                               as acct_desc,
       g.task_lvl1_name                          as task_lvl1_name,
       g.task_lvl2_name                          as task_lvl2_name,
       g.task_lvl3_name                          as task_lvl3_name,
       g.task_lvl4_name                          as task_lvl4_name,
       b.reg_name                                as reg_name,
       ft.rep                                    as rep,
       COALESCE(ft.service_date, a.invoice_date) AS service_date,
       CASE
           WHEN ft.service_date IS NULL THEN 'Y'::character varying
           ELSE 'N'::character varying
           END                                   AS serv_date_null,
       ft.bpa_number                             as bpa_number,
       ma.worktype                               as worktype,
       ma.location                               as location,
       ma.description                            as description,
       ma.status                                 as status,
       ma.active_flag                            as active_flag,
       ma.max_name                               as max_name,
       sum(a.det_amount)                         AS amount
FROM finance.finods_oneoxy_trans_opex a
         LEFT JOIN finance.finods_cost_center_mv b ON a.cost_center = b.cost_center
         LEFT JOIN finance.crc_bu_org4_maapping bu ON b.org_seqno = bu.org_seqno
         LEFT JOIN (select distinct elem.element_cd,
                                    elem.element_lvl1_name,
                                    elem.element_lvl2_name,
                                    elem.element_lvl3_name,
                                    elem.element_lvl4_name,
                                    elem.element_lvl5_name
                    from finance.finods_element_mv_tmp elem) c ON a.element_cd::text = c.element_cd::text
         LEFT JOIN finance.finods_hyperion_account d ON a.hyperion_acct_cd::text = d.hyperion_acct_cd::text
         LEFT JOIN finance.pa_pa_projects_all e ON a.project_cd::text = e.segment1::text
         LEFT JOIN finance.finods_account f ON a.acct_cd::text = f.acct_cd::text
         LEFT JOIN (select distinct task.task_number,
                                    task.task_template,
                                    task.task_lvl1_name,
                                    task.task_lvl2_name,
                                    task.task_lvl3_name,
                                    task.task_lvl4_name
                    from finance.finods_tasks_mv task) g
                   ON a.task_cd::text = g.task_number::text AND a.task_template::text = g.task_template::text
         LEFT JOIN finance.invoices ft
                   ON a.vendor_no::character varying::text = ft.vendor_no::text AND a.invoice_no::text = ft.invoice_no::text
         LEFT JOIN finance.maximo_workorder_v ma ON ma.wonum::text = a.job_no::text
WHERE (a.company_cd IN (SELECT opex_company_cd.company_cd
                        FROM finance.opex_company_cd)) AND (a.line_no IN (SELECT opex_line_no.line_no
                                                                          FROM finance.opex_line_no))
   OR a.company_cd::text = '011977'::character varying::text AND a.line_no = 10
GROUP BY a.book_date, bu.business_unit, a.creation_date, a.project_cd, a.company_cd, a.cost_center, a.element_cd,
         a.task_cd, a.task_template, a.acct_cd, a.clearing_no, a.line_no, a.line_desc, a.jva_bill_code, a.je_batch_name,
         a.task_name, a.default_cost_center, a.vendor_name, a.invoice_no, a.invoice_date, a.trans_source, a.desc_lines,
         a.vendor_no, a.job_no, a.attachment1, a.attachment2, a.attachment3, a.attachment4, b.cost_center_name,
         b.at_name, b.subat_name, b.orglev4_name, b.orglev5_name, c.element_lvl1_name, c.element_lvl2_name,
         c.element_lvl3_name, c.element_lvl4_name, c.element_lvl5_name, d.hyperion_acct_cd_short, d.hyperion_desc,
         e.name, e.project_type, f.acct_desc, g.task_lvl1_name, g.task_lvl2_name, g.task_lvl3_name, g.task_lvl4_name,
         b.reg_name, ft.rep, ft.service_date,
         CASE
             WHEN ft.service_date IS NULL THEN 'Y'::character varying
             ELSE 'N'::character varying
             END, ft.bpa_number, ma.worktype, ma."location", ma.description, ma.status, ma.active_flag, ma.max_name
with no schema binding;

alter table doe_v2
    owner to juan;

grant select on doe_v2 to david;

