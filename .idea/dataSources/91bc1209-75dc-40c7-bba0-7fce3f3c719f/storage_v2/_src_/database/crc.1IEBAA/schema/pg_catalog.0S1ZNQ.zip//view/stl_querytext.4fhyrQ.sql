create view stl_querytext(userid, xid, pid, query, sequence, text) as
SELECT stll_querytext.userid,
       stll_querytext.xid,
       stll_querytext.pid,
       stll_querytext.query,
       stll_querytext."sequence",
       stll_querytext.text
FROM stll_querytext;

alter table stl_querytext
    owner to rdsdb;

