CREATE OR REPLACE VIEW xspoc_high_res_views.dv_tblcarddata_decoded AS
SELECT "nodeid"
     , "date"
     , "torqueplotmintorque"
     , "torqueplotminenergyb"
     , "analysisdate"
     , "fillbasepct"
     , "cardarea"
     , "causeid"
     , "electrogramcardb"
     , "processcard"
     , "surfacecardb"
     , "positionlimit2"
     , "spm"
     , "runtime"
     , "secondarypumpfillage"
     , "malpositionlimit"
     , "torqueplotcurrent"
     , "cardtype"
     , "torqueplotcurrentb"
     , "saved"
     , "loadlimit2"
     , "permissibleloaddownb"
     , "malloadlimit"
     , "strokelength"
     , "downholecard"
     , "loadlimit"
     , "loadspanlimit"
     , "predictedcard"
     , "loloadlimit"
     , "correctedcard"
     , "torqueplotminenergy"
     , "positionlimit"
     , "downholecardb"
     , "pocdownholecard"
     , "torqueplotmintorqueb"
     , "arealimit"
     , "predictedcardb"
     , "permissibleloadupb"
     , "area"
     , "hiloadlimit"
     , "pocdhcard"
     , "fillage"
     , "pocdownholecardb"
     , "surfacecard"
     , "partition_1"        "xspoc_source"
     , "max"("partition_2") "p_2"
FROM xspoc_high_res.tblcarddata_decoded
GROUP BY "torqueplotmintorque", "torqueplotminenergyb", "analysisdate", "fillbasepct", "cardarea", "causeid",
         "electrogramcardb", "processcard", "surfacecardb", "positionlimit2", "spm", "runtime", "secondarypumpfillage",
         "malpositionlimit", "torqueplotcurrent", "cardtype", "torqueplotcurrentb", "nodeid", "saved", "loadlimit2",
         "permissibleloaddownb", "malloadlimit", "strokelength", "downholecard", "loadlimit", "loadspanlimit",
         "predictedcard", "loloadlimit", "correctedcard", "torqueplotminenergy", "positionlimit", "downholecardb",
         "pocdownholecard", "date", "torqueplotmintorqueb", "arealimit", "predictedcardb", "permissibleloadupb", "area",
         "hiloadlimit", "pocdhcard", "fillage", "pocdownholecardb", "surfacecard", "partition_1"
ORDER BY "nodeid" ASC, "date" DESC
with no schema binding;

alter table dv_tblcarddata_decoded
    owner to crc;

