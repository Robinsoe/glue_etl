CREATE VIEW xspoc_high_res_views.dv_tblxdiagresults AS
SELECT "nodeid"
     , "date"
     , "grosspumpstroke"
     , "motorload"
     , "maxrodload"
     , "currentkwh"
     , "tubingmovement"
     , "loadshift"
     , "eleccostmintorqueperbo"
     , "pumpfriction"
     , "monthlyeleccost"
     , "avgdhdsload"
     , "avgdhuspoload"
     , "tubingpressure"
     , "gearboxloadpct"
     , "mintorquegbloadpct"
     , "minenergycbe"
     , "downholeanalysislocale"
     , "currentmcb"
     , "eleccostmonthly"
     , "downholeanalysis"
     , "avgdhusload"
     , "pprl"
     , "minenergymonthlyelec"
     , "fluidsg"
     , "rodanalysislocale"
     , "minenergyelecbg"
     , "currentcbe"
     , "minenergygbloadpct"
     , "dryrodweight"
     , "minmonthlyeleccost"
     , "unitstructload"
     , "minenergyelecbo"
     , "mineleccostperbg"
     , "mintorquecbe"
     , "mintorqueelecbo"
     , "currentelecbo"
     , "badsg"
     , "mprl"
     , "mintorqueelecbg"
     , "currentelecbg"
     , "pumpeffpct"
     , "inputanalysis"
     , "rodanalysis"
     , "mingbtorque"
     , "pumpsize"
     , "netstrokeapparent"
     , "analysisdate"
     , "pumpintakepressure"
     , "surfaceanalysislocale"
     , "mintorquemcb"
     , "mintorquemonthlyelec"
     , "pumpcondition"
     , "downholecapacityruntimefillage"
     , "grosspumpdisplacement"
     , "oilapigravity"
     , "minhp"
     , "eleccostperbg"
     , "polrodhp"
     , "cardtype"
     , "grossprod"
     , "casingpressure"
     , "mintorquekwh"
     , "minenergyclf"
     , "eleccostperbo"
     , "addoilproduction"
     , "watersg"
     , "tubingleak"
     , "fillagepct"
     , "downholecapacityruntime"
     , "electcostminenergyperbo"
     , "peakgbtorque"
     , "avgdhdspoload"
     , "fluidloadonpump"
     , "inputanalysislocale"
     , "currentclf"
     , "minenergymcb"
     , "pumpstroke"
     , "pumpefficiency"
     , "balanceunit"
     , "currentmonthlyelec"
     , "gearboxtorquerating"
     , "pumpcond1"
     , "systemeffpct"
     , "watercutpct"
     , "bouyrodweight"
     , "surfaceanalysis"
     , "pofluidload"
     , "friction"
     , "minenergbtorque"
     , "downholecapacity24"
     , "mintorqueclf"
     , "netprod"
     , "minenergykwh"
     , "pumpcond2"
     , "fluidlevelxdiag"
     , "partition_1"        "xspoc_source"
     , "max"("partition_2") "p_2"
FROM xspoc_high_res.tblxdiagresults
GROUP BY "grosspumpstroke", "motorload", "maxrodload", "currentkwh", "tubingmovement", "loadshift",
         "eleccostmintorqueperbo", "pumpfriction", "monthlyeleccost", "avgdhdsload", "avgdhuspoload", "tubingpressure",
         "gearboxloadpct", "mintorquegbloadpct", "minenergycbe", "downholeanalysislocale", "currentmcb",
         "eleccostmonthly", "downholeanalysis", "avgdhusload", "pprl", "minenergymonthlyelec", "fluidsg",
         "rodanalysislocale", "minenergyelecbg", "currentcbe", "minenergygbloadpct", "dryrodweight",
         "minmonthlyeleccost", "unitstructload", "minenergyelecbo", "mineleccostperbg", "mintorquecbe",
         "mintorqueelecbo", "currentelecbo", "badsg", "mprl", "mintorqueelecbg", "currentelecbg", "pumpeffpct",
         "inputanalysis", "rodanalysis", "mingbtorque", "pumpsize", "netstrokeapparent", "analysisdate",
         "pumpintakepressure", "surfaceanalysislocale", "mintorquemcb", "mintorquemonthlyelec", "pumpcondition",
         "downholecapacityruntimefillage", "grosspumpdisplacement", "oilapigravity", "minhp", "eleccostperbg",
         "polrodhp", "cardtype", "grossprod", "nodeid", "casingpressure", "mintorquekwh", "minenergyclf",
         "eleccostperbo", "addoilproduction", "watersg", "tubingleak", "fillagepct", "downholecapacityruntime",
         "electcostminenergyperbo", "peakgbtorque", "avgdhdspoload", "fluidloadonpump", "inputanalysislocale",
         "currentclf", "minenergymcb", "date", "pumpstroke", "pumpefficiency", "balanceunit", "currentmonthlyelec",
         "gearboxtorquerating", "pumpcond1", "systemeffpct", "watercutpct", "bouyrodweight", "surfaceanalysis",
         "pofluidload", "friction", "minenergbtorque", "downholecapacity24", "mintorqueclf", "netprod", "minenergykwh",
         "pumpcond2", "fluidlevelxdiag", "partition_1"
ORDER BY "nodeid" ASC, "date" DESC
with no schema binding;

alter table dv_tblxdiagresults
    owner to crc;

