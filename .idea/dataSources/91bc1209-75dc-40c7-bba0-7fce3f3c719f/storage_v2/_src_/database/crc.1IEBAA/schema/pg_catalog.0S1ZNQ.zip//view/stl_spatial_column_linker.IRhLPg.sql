create view stl_spatial_column_linker(query, tbl, columnname, sqloperation) as
SELECT stll_spatial_column_linker.query,
       stll_spatial_column_linker.tbl,
       stll_spatial_column_linker.columnname,
       stll_spatial_column_linker.sqloperation
FROM stll_spatial_column_linker;

alter table stl_spatial_column_linker
    owner to rdsdb;

