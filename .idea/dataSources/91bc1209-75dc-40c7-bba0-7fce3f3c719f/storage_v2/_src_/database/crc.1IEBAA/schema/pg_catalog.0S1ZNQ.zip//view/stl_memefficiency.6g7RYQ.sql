create view stl_memefficiency(recordtime, node, memrequested, memtotal, overhead, wastage, counter) as
SELECT stll_memefficiency.recordtime,
       stll_memefficiency.node,
       stll_memefficiency.memrequested,
       stll_memefficiency.memtotal,
       stll_memefficiency.overhead,
       stll_memefficiency.wastage,
       stll_memefficiency.counter
FROM stll_memefficiency;

alter table stl_memefficiency
    owner to rdsdb;

