create view stl_disk_extent_splits
            (split_time, owner, host, diskno, tbl, col, addr, start, size_before, size_after, new_start, new_size) as
SELECT stll_disk_extent_splits.split_time,
       stll_disk_extent_splits."owner",
       stll_disk_extent_splits."host",
       stll_disk_extent_splits.diskno,
       stll_disk_extent_splits.tbl,
       stll_disk_extent_splits.col,
       stll_disk_extent_splits.addr,
       stll_disk_extent_splits."start",
       stll_disk_extent_splits.size_before,
       stll_disk_extent_splits.size_after,
       stll_disk_extent_splits.new_start,
       stll_disk_extent_splits.new_size
FROM stll_disk_extent_splits;

alter table stl_disk_extent_splits
    owner to rdsdb;

