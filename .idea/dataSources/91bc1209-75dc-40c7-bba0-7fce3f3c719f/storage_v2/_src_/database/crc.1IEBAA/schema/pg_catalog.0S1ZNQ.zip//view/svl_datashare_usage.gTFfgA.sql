create view svl_datashare_usage
            (share_id, share_name, request_type, object_type, object_oid, object_name, consumer_account,
             consumer_namespace, recordtime, status, error)
as
SELECT stl_datashare_request_producer.shareid           AS share_id,
       stl_datashare_request_producer.sharename         AS share_name,
       CASE
           WHEN stl_datashare_request_producer.api_call = 5
               THEN 'GET FUNCTION'::character varying::character varying(25)
           WHEN stl_datashare_request_producer.api_call = 4
               THEN 'CHECK RELATION PERMISSION'::character varying::character varying(25)
           ELSE 'GET RELATION'::character varying::character varying(25)
           END                                          AS request_type,
       CASE
           WHEN stl_datashare_request_producer.obj_type = 2 THEN 'TABLE'::character varying::character varying(20)
           WHEN stl_datashare_request_producer.obj_type = 3 THEN 'VIEW'::character varying::character varying(20)
           WHEN stl_datashare_request_producer.obj_type = 4
               THEN 'LATE BINDING VIEW'::character varying::character varying(20)
           WHEN stl_datashare_request_producer.obj_type = 5
               THEN 'MATERIALIZED VIEW'::character varying::character varying(20)
           WHEN stl_datashare_request_producer.obj_type = 6 THEN 'FUNCTION'::character varying::character varying(20)
           ELSE 'UNKNOWN'::character varying::character varying(20)
           END                                          AS object_type,
       stl_datashare_request_producer.obj_oid           AS object_oid,
       stl_datashare_request_producer.obj_name          AS object_name,
       stl_datashare_request_producer.consumeraccountid AS consumer_account,
       stl_datashare_request_producer.consumernamespace AS consumer_namespace,
       stl_datashare_request_producer.endtime           AS recordtime,
       stl_datashare_request_producer.status,
       stl_datashare_request_producer.message           AS error
FROM stl_datashare_request_producer
WHERE stl_datashare_request_producer.shareid <> 0
  AND stl_datashare_request_producer.api_call >= 2
  AND stl_datashare_request_producer.api_call <= 5;

alter table svl_datashare_usage
    owner to rdsdb;

