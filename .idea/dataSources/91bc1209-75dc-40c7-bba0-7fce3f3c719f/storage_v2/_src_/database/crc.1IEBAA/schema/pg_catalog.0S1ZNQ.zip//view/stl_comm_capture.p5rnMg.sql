create view stl_comm_capture
            (host_ip, recordtime, src_mac, src_ip, src_port, dst_mac, dst_ip, dst_port, ip_id, ip_len, ip_frags,
             ip_frag_offset, cmd_code, seqnum, channel, src_slice, dst_slice, len, is_bcast, ack_reply, ack_xon,
             sync_msg, fragment)
as
SELECT stll_comm_capture.host_ip,
       stll_comm_capture.recordtime,
       stll_comm_capture.src_mac,
       stll_comm_capture.src_ip,
       stll_comm_capture.src_port,
       stll_comm_capture.dst_mac,
       stll_comm_capture.dst_ip,
       stll_comm_capture.dst_port,
       stll_comm_capture.ip_id,
       stll_comm_capture.ip_len,
       stll_comm_capture.ip_frags,
       stll_comm_capture.ip_frag_offset,
       stll_comm_capture.cmd_code,
       stll_comm_capture.seqnum,
       stll_comm_capture.channel,
       stll_comm_capture.src_slice,
       stll_comm_capture.dst_slice,
       stll_comm_capture.len,
       stll_comm_capture.is_bcast,
       stll_comm_capture.ack_reply,
       stll_comm_capture.ack_xon,
       stll_comm_capture.sync_msg,
       stll_comm_capture.fragment
FROM stll_comm_capture;

alter table stl_comm_capture
    owner to rdsdb;

