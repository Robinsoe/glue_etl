create view stl_querytext_internal(userid, xid, pid, query, sequence, text) as
SELECT stll_querytext_internal.userid,
       stll_querytext_internal.xid,
       stll_querytext_internal.pid,
       stll_querytext_internal.query,
       stll_querytext_internal."sequence",
       stll_querytext_internal.text
FROM stll_querytext_internal;

alter table stl_querytext_internal
    owner to rdsdb;

