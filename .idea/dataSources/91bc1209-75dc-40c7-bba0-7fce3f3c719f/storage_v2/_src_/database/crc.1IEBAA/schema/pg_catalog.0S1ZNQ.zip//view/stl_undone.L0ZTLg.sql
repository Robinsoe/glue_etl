create view stl_undone(userid, xact_id, xact_id_undone, undo_start_ts, undo_end_ts, table_id) as
SELECT stll_undone.userid,
       stll_undone.xact_id,
       stll_undone.xact_id_undone,
       stll_undone.undo_start_ts,
       stll_undone.undo_end_ts,
       stll_undone.table_id
FROM stll_undone;

alter table stl_undone
    owner to rdsdb;

