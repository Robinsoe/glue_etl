create view stl_concurrency_scaling_usage
            (recordtime, query, cluster, starttime, endtime, request_id, incurred_usage_ms) as
SELECT stll_concurrency_scaling_usage.recordtime,
       stll_concurrency_scaling_usage.query,
       stll_concurrency_scaling_usage."cluster",
       stll_concurrency_scaling_usage.starttime,
       stll_concurrency_scaling_usage.endtime,
       stll_concurrency_scaling_usage.request_id,
       stll_concurrency_scaling_usage.incurred_usage_ms
FROM stll_concurrency_scaling_usage;

alter table stl_concurrency_scaling_usage
    owner to rdsdb;

