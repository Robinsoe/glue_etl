CREATE VIEW xspoc_high_res_views.dv_tbldatahistory AS
SELECT nodeid
     , date
     , address
     , value
     , partition_1      xspoc_source
     , max(partition_2) p_2
FROM xspoc_high_res.tbldatahistory
GROUP BY address, nodeid, value, date, partition_1
with no schema binding;

alter table dv_tbldatahistory
    owner to crc;

